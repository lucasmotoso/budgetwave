// path: budgetwave/scripts/state.js
// Núcleo de estado global e EventBus do BudgetWave.
// Compatível com módulos existentes (ui:tab, settings:changed, tx:changed, cat:changed, db:ready, ui:toast).

(() => {
  // -----------------------------
  // EventBus simples e resiliente
  // -----------------------------
  const _map = new Map();

  function on(evt, fn) {
    if (!evt || typeof fn !== 'function') return;
    if (!_map.has(evt)) _map.set(evt, new Set());
    _map.get(evt).add(fn);
  }

  function off(evt, fn) {
    _map.get(evt)?.delete(fn);
  }

  function once(evt, fn) {
    const wrapper = (detail) => {
      try { fn(detail); } finally { off(evt, wrapper); }
    };
    on(evt, wrapper);
  }

  function emit(evt, detail) {
    const listeners = _map.get(evt);
    if (!listeners || listeners.size === 0) return;
    // clona para evitar problema se alguém registrar/deregistrar durante o loop
    [...listeners].forEach(fn => {
      try { fn(detail); } catch (e) { console.error(`[eventBus:${evt}]`, e); }
    });
  }

  // Expor globalmente (API compatível com código existente)
  window.eventBus = { on, off, once, emit };

  // -----------------------------
  // Estado global
  // -----------------------------
  const THEME_KEY = 'bw_theme';
  const TAB_KEY = 'bw_last_tab';
  const MONTH_KEY = 'bw_current_month';

  // Tema inicial: localStorage -> prefers-color-scheme -> 'dark'
  function detectInitialTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'dark' || saved === 'light') return saved;
    const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    return prefersDark ? 'dark' : 'light';
  }

  // Mês inicial: salvo -> mês atual
  function detectInitialMonth() {
    const saved = localStorage.getItem(MONTH_KEY);
    if (saved && /^\d{4}-\d{2}$/.test(saved)) return saved;
    const ym = (window.Utils?.ymKey?.(new Date())) || (() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    })();
    return ym;
  }

  // Aba inicial: salva (session) -> dashboard
  function detectInitialTab() {
    const saved = sessionStorage.getItem(TAB_KEY);
    return saved || 'dashboard';
  }

  const state = {
    theme: detectInitialTheme(),
    currentTab: detectInitialTab(),
    currentMonth: detectInitialMonth(),
  };

  // Aplica tema no <html>
  function applyThemeToDOM(theme) {
    document.documentElement.setAttribute('data-theme', theme);
  }
  applyThemeToDOM(state.theme);

  // -----------------------------
  // Mutadores públicos
  // -----------------------------
  function setTheme(theme) {
    if (theme !== 'dark' && theme !== 'light') return;
    if (state.theme === theme) return;
    state.theme = theme;
    localStorage.setItem(THEME_KEY, theme);
    applyThemeToDOM(theme);
    window.eventBus.emit('settings:changed', { key: 'theme', value: theme });
  }

  function toggleTheme() {
    setTheme(state.theme === 'dark' ? 'light' : 'dark');
  }

  function setTab(tabId) {
    if (!tabId) return;
    state.currentTab = tabId;
    sessionStorage.setItem(TAB_KEY, tabId);
    window.eventBus.emit('ui:tab', tabId);
  }

  function setMonth(ym) {
    if (!/^\d{4}-\d{2}$/.test(ym)) return;
    if (state.currentMonth === ym) return;
    state.currentMonth = ym;
    localStorage.setItem(MONTH_KEY, ym);
    window.eventBus.emit('ui:month', ym);
  }

  // Getters simples (evitam acoplamento direto ao objeto)
  function getTheme()        { return state.theme; }
  function getTab()          { return state.currentTab; }
  function getMonth()        { return state.currentMonth; }

  // -----------------------------
  // Exposição pública
  // -----------------------------
  window.AppState = Object.freeze({
    // leitura
    getTheme, getTab, getMonth,
    // escrita
    setTheme, toggleTheme, setTab, setMonth,
    // acesso direto (se realmente precisar)
    state,
  });

  // -----------------------------
  // Boot leve
  // -----------------------------
  document.addEventListener('DOMContentLoaded', () => {
    // Garante o atributo data-theme desde o início
    applyThemeToDOM(state.theme);
    // Informa aos módulos que o estado inicial está pronto
    // (db.js emitirá 'db:ready' depois que o IndexedDB abrir)
    window.eventBus.emit('ui:tab', state.currentTab);
  });
})();
