// path: budgetwave/scripts/settings.js
/* Configurações → Regras automáticas (CRUD)
   settings.rules = [{ id, keywords:[], categoryId }]
   - Fallbacks internos para escapeHtml e normalizeText
   - Repopulação robusta de categorias
   - Re-render automático em settings:changed / cat:changed / ao abrir a aba
*/
(function(){
  const $ = (q)=> document.querySelector(q);

  // ---- Fallbacks (não colidem com os já existentes) ----
  const escapeHtml = (str)=>{
    const s = String(str ?? '');
    return s
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  };
  const norm = (s)=>{
    if (typeof window.normalizeText === 'function') return window.normalizeText(s);
    return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  };

  // ---- Storage ----
  async function loadRules(){
    try { return (await getSetting('rules')) || []; }
    catch { return []; }
  }
  async function saveRules(rules){
    await setSetting('rules', Array.isArray(rules)?rules:[]);
    eventBus.dispatch('settings:changed');
  }

  // ---- UI helpers ----
  async function waitCategoriesReady(maxTries=10, delay=200){
    for(let i=0;i<maxTries;i++){
      const cats = await listCategories();
      if (cats && cats.length) return cats;
      await new Promise(r=>setTimeout(r, delay));
    }
    return await listCategories(); // última tentativa (pode ser vazio)
  }

  async function populateCategorySelect(){
    const sel = $('#rule-category'); if(!sel) return;
    const cats = await waitCategoriesReady();
    sel.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = ''; opt0.textContent = '— selecione —';
    sel.appendChild(opt0);
    for (const c of cats){
      const o = document.createElement('option');
      o.value = c.id; o.textContent = c.name;
      sel.appendChild(o);
    }
  }

  function resetForm(){
    $('#rule-id')?.setAttribute('value',''); // não depende de CSS do hidden
    const kw = $('#rule-keywords'); if(kw) kw.value='';
    const sel = $('#rule-category'); if(sel) sel.value='';
    $('#rule-keywords')?.focus();
  }

  function trForRule(rule, catsById){
    const catName = catsById.get(rule.categoryId)?.name || '—';
    const kws = rule.keywords.join(', ');
    return `
      <td>${escapeHtml(kws)}</td>
      <td>${escapeHtml(catName)}</td>
      <td class="row-actions">
        <button class="btn" data-act="edit" data-id="${rule.id}" title="Editar">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button class="btn" data-act="del" data-id="${rule.id}" title="Excluir">
          <i class="fa-solid fa-trash"></i>
        </button>
      </td>
    `;
  }

  async function renderTable(){
    const tbody = document.querySelector('#rule-table tbody'); if(!tbody) return;
    const [rules, cats] = await Promise.all([loadRules(), listCategories()]);
    const catsById = new Map(cats.map(c=>[c.id,c]));
    tbody.innerHTML = '';
    for(const r of rules){
      const tr = document.createElement('tr');
      tr.innerHTML = trForRule(r, catsById);
      tbody.appendChild(tr);
    }
  }

  function parseKeywords(str){
    return String(str||'')
      .split(',')
      .map(s=> norm(s.trim()))
      .filter(Boolean);
  }

  // ---- Actions ----
  async function onSubmit(e){
    e?.preventDefault?.();

    const id    = $('#rule-id')?.value || uuid();
    const kwRaw = $('#rule-keywords')?.value || '';
    const catId = $('#rule-category')?.value || '';
    if(!kwRaw.trim() || !catId){
      showToast('Preencha as palavras-chave e selecione uma categoria.');
      return;
    }

    const rules = await loadRules();
    const idx = rules.findIndex(r=> r.id===id);
    const data = { id, keywords: parseKeywords(kwRaw), categoryId: catId };
    if(idx>=0) rules[idx]=data; else rules.push(data);

    await saveRules(rules);
    showToast('Regra salva.');
    await renderTable();
    resetForm();
  }

  async function onTableClick(ev){
    const btn = ev.target.closest('button[data-act]'); if(!btn) return;
    const id  = btn.getAttribute('data-id');
    const act = btn.getAttribute('data-act');

    const rules = await loadRules();
    const i = rules.findIndex(r=> r.id===id);
    if(i<0) return;

    if(act==='edit'){
      $('#rule-id').value = rules[i].id;
      $('#rule-keywords').value = rules[i].keywords.join(', ');
      $('#rule-category').value = rules[i].categoryId;
      $('#rule-keywords')?.focus();
      return;
    }
    if(act==='del'){
      if(!confirm('Excluir esta regra?')) return;
      rules.splice(i,1);
      await saveRules(rules);
      showToast('Regra excluída.');
      renderTable();
      return;
    }
  }

  // ---- Wiring (idempotente) ----
  function wireOnce(){
    const form = document.querySelector('#rule-form');
    if(!form || form.dataset.wired==='1') return;
    form.dataset.wired = '1';
    form.addEventListener('submit', onSubmit);
    document.querySelector('#rule-reset')?.addEventListener('click', resetForm);
    document.querySelector('#rule-table')?.addEventListener('click', onTableClick);
  }

  async function refreshAll(){
    await populateCategorySelect();
    await renderTable();
    wireOnce();
  }

  // ---- Boot & eventos globais ----
  eventBus.on('db:ready', refreshAll);
  if (window.dbRef) refreshAll();                // fallback se DB já está pronto
  eventBus.on('cat:changed', refreshAll);        // CRUD/seed de categorias
  eventBus.on('settings:changed', renderTable);  // re-render quando regras mudarem
  eventBus.on('ui:tab', (tab)=>{ if(tab==='config') refreshAll(); });

  // Gancho de debug opcional
  window.BW_settings = { loadRules, saveRules, renderTable, populateCategorySelect };
})();
