// path: budgetwave/scripts/transactions.js
/* Parte 3 — Lançamentos + Dashboard
   - KPIs e Top5 (já feitos)
   - Formulário para adicionar
   - Filtros (mês, texto, categoria, tipo)
   - Listagem com excluir e duplicar
*/
// path: budgetwave/scripts/transactions.js
// PATCH — cola perto do topo do arquivo (após imports/vars), sem remover nada existente.

(function () {
  const BUS = window.eventBus || { on(){}, emit(){} };

  // Reidrata o select de categoria quando estiver vazio/só com placeholder
  function ensureTxCategoryOptions() {
    const sel = document.getElementById('tx-category');
    if (!sel) return;
    // se só tem placeholder, pede hidratação
    if (sel.options.length <= 1) {
      if (typeof window.hydrateCategorySelects === 'function') {
        window.hydrateCategorySelects();
      }
    }
    // se a hidratação correu antes do seed, tenta de novo um tick depois
    if (sel.options.length <= 1) {
      setTimeout(() => {
        if (sel.options.length <= 1 && typeof window.hydrateCategorySelects === 'function') {
          window.hydrateCategorySelects();
        }
      }, 120);
    }
  }

  // Observa o form de lançamentos: se for re-renderizado ou limpar o select, reidrata
  function watchTxForm() {
    const form = document.getElementById('tx-form');
    if (!form || watchTxForm._on) return;
    watchTxForm._on = true;

    const mo = new MutationObserver((mutations) => {
      let needs = false;
      for (const m of mutations) {
        if (m.type === 'childList') {
          if ([...m.addedNodes, ...m.removedNodes].some(n =>
            n?.nodeType === 1 &&
            ((n.id === 'tx-category') || (n.querySelector && n.querySelector('#tx-category')))
          )) {
            needs = true; break;
          }
        } else if (m.type === 'attributes' && m.target?.id === 'tx-category') {
          needs = true; break;
        }
      }
      if (needs) ensureTxCategoryOptions();
    });
    try {
      mo.observe(form, { childList: true, subtree: true, attributes: true, attributeFilter: ['innerHTML'] });
    } catch {}
  }

  // Reforços nos momentos certos
  document.addEventListener('DOMContentLoaded', () => {
    watchTxForm();
    ensureTxCategoryOptions();
  });

  BUS.on('db:ready', () => {
    watchTxForm();
    ensureTxCategoryOptions();
    setTimeout(ensureTxCategoryOptions, 150); // pós-seed
  });

  BUS.on('cat:changed', ensureTxCategoryOptions);

  BUS.on('ui:tab', (tabId) => {
    if (tabId === 'lancamentos') {
      ensureTxCategoryOptions();
      setTimeout(ensureTxCategoryOptions, 150); // re-render tardio
    }
  });

  // Se o botão reset do form for usado, reidrata depois
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button[type="reset"], [data-action="tx-reset"]');
    if (!btn) return;
    setTimeout(ensureTxCategoryOptions, 0);
  });
})();

function currentYM(){
  const d=new Date(); return { y:d.getFullYear(), m:d.getMonth()+1 };
}
function ymToInputValue(y,m){ return `${y}-${String(m).padStart(2,'0')}`; }
function formatMonthLabel(y,m){
  const d = new Date(y, m-1, 1);
  return d.toLocaleString('pt-BR',{ month:'long', year:'numeric' });
}

/* ====== Dashboard (KPIs + Top5) ====== */
async function loadMonthData(){
  const {y,m} = getFilterMonth();
  const txs = await getTxByMonth(y, m);
  const cats = await listCategories();
  return { txs, cats, y, m };
}
function calcKPIs(txs){
  let income=0, expense=0;
  for(const t of txs){
    if(t.type==='income') income += t.amount||0;
    else if(t.type==='expense') expense += t.amount||0;
  }
  return { income, expense, balance: income - expense };
}
function categoryLookup(cats){ const map=new Map(); cats.forEach(c=>map.set(c.id,c)); return (id)=> map.get(id) || null; }
function renderKPIs({income, expense, balance}){
  const i=qs('#kpi-income'), e=qs('#kpi-expense'), b=qs('#kpi-balance');
  if(i) i.textContent=toBRL(income);
  if(e) e.textContent=toBRL(expense);
  if(b) b.textContent=toBRL(balance);
}
function renderTop5(txs, cats, y, m){
  const list = qs('#top5-list'); const period = qs('#top5-period');
  if(!list) return;
  const getCat = categoryLookup(cats);
  if(period) period.textContent = formatMonthLabel(y,m);

  const expenses = txs.filter(t=>t.type==='expense')
                      .sort((a,b)=> (b.amount||0) - (a.amount||0))
                      .slice(0,5);

  list.innerHTML = '';
  if(expenses.length===0){ list.innerHTML = `<li>Sem despesas no período.</li>`; return; }

  const frag = document.createDocumentFragment();
  for(const e of expenses){
    const c = getCat(e.categoryId);
    const li = document.createElement('li');

    const left = document.createElement('div');
    left.className='top5__name';
    left.innerHTML = `
      <span class="top5__cat" style="--cat:${c?.color||'#999'}">
        <i class="fa-solid ${c?.icon||'fa-tag'}" style="color:${c?.color||'inherit'}"></i>
        ${c?.name||'Sem categoria'}
      </span>
      <span>${e.description || '(sem descrição)'}</span>
    `;

    const right = document.createElement('div');
    right.className='top5__amount';
    right.textContent = toBRL(e.amount||0);

    li.append(left, right);
    frag.appendChild(li);
  }
  list.appendChild(frag);
}
async function refreshDashboard(){
  const { txs, cats, y, m } = await loadMonthData();
  renderKPIs(calcKPIs(txs));
  renderTop5(txs, cats, y, m);
}

/* ====== Lançamentos — filtros & listagem ====== */
const txFilters = {
  month: null,          // 'YYYY-MM' (definido em init)
  text: '',
  categoryId: 'all',
  type: 'all',
};

function getFilterMonth(){
  // usa filtro escolhido ou mês atual
  if(!txFilters.month){
    const {y,m} = currentYM();
    txFilters.month = ymToInputValue(y,m);
  }
  const [y,m] = txFilters.month.split('-').map(Number);
  return { y, m };
}

async function refreshTxTable(){
  const { y, m } = getFilterMonth();
  const [txs, cats] = await Promise.all([
    getTxByMonth(y, m),
    listCategories()
  ]);

  // filtros text/cat/type
  const text = normalizeText(txFilters.text);
  const filtered = txs.filter(t=>{
    if(txFilters.type!=='all' && t.type!==txFilters.type) return false;
    if(txFilters.categoryId!=='all' && t.categoryId!==txFilters.categoryId) return false;
    if(text && !normalizeText(t.description).includes(text)) return false;
    return true;
  }).sort((a,b)=> (a.date<b.date?1:-1));

  renderTxRows(filtered, cats);
}

function renderTxRows(txs, cats){
  const tbody = qs('#tx-table tbody');
  if(!tbody) return;
  const getCat = categoryLookup(cats);
  tbody.innerHTML = '';

  if(txs.length===0){
    const tr = document.createElement('tr');
    const td = document.createElement('td'); td.colSpan=6; td.textContent='Nenhum lançamento encontrado.';
    tr.appendChild(td); tbody.appendChild(tr); return;
  }

  const frag = document.createDocumentFragment();
  for(const t of txs){
    const c = getCat(t.categoryId);
    const tr = document.createElement('tr');

    const tdDate = document.createElement('td'); tdDate.textContent = formatDMY(t.date);
    const tdDesc = document.createElement('td'); tdDesc.textContent = t.description||'—';

    const tdCat = document.createElement('td');
    tdCat.innerHTML = `
      <span class="badge cat">
        <i class="fa-solid ${c?.icon||'fa-tag'}" style="color:${c?.color||'inherit'}"></i>
        ${c?.name||'Sem categoria'}
      </span>
    `;

    const tdType = document.createElement('td'); tdType.textContent = t.type==='income'?'Receita':'Despesa';

    const tdAmount = document.createElement('td'); tdAmount.style.fontWeight='700'; tdAmount.textContent = toBRL(t.amount||0);

    const tdActions = document.createElement('td');
    tdActions.className='row-actions';
    tdActions.innerHTML = `
      <!--<button class="btn" data-action="edit" data-id="${t.id}"><i class="fa-solid fa-pen"></i></button>-->
      <button class="btn" data-action="dup" data-id="${t.id}" title="Duplicar"><i class="fa-solid fa-copy"></i></button>
      <button class="btn" data-action="del" data-id="${t.id}" title="Excluir"><i class="fa-solid fa-trash"></i></button>
    `;

    tr.append(tdDate, tdDesc, tdCat, tdType, tdAmount, tdActions);
    frag.appendChild(tr);
  }
  tbody.appendChild(frag);
}

/* ====== Lançamentos — formulário ====== */
function setDefaultDates(){
  const d = new Date();
  const inputDate = qs('#tx-date');
  if(inputDate && !inputDate.value){
    const m = String(d.getMonth()+1).padStart(2,'0');
    const day = String(d.getDate()).padStart(2,'0');
    inputDate.value = `${d.getFullYear()}-${m}-${day}`;
  }
  const inputMonth = qs('#tx-filter-month');
  if(inputMonth && !inputMonth.value){
    const {y,m} = currentYM();
    inputMonth.value = ymToInputValue(y,m);
    txFilters.month = inputMonth.value;
  }
}

async function loadCategoriesIntoSelects(){
  const cats = await listCategories();
  // form select
  const selForm = qs('#tx-category');
  if(selForm){
    selForm.innerHTML = cats.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
  }
  // filter select
  const selFilter = qs('#tx-filter-category');
  if(selFilter){
    const opts = [`<option value="all">Todas</option>`].concat(
      cats.map(c=>`<option value="${c.id}">${c.name}</option>`)
    );
    selFilter.innerHTML = opts.join('');
  }
}

function readTxForm(){
  const date = qs('#tx-date')?.value;
  const description = qs('#tx-desc')?.value?.trim();
  const categoryId = qs('#tx-category')?.value;
  const type = qs('#tx-type')?.value;
  const amountRaw = qs('#tx-amount')?.value;

  const amount = parseBRNumber(amountRaw);
  if(!date) throw new Error('Data obrigatória');
  if(!description) throw new Error('Descrição obrigatória');
  if(!categoryId) throw new Error('Categoria obrigatória');
  if(!type) throw new Error('Tipo obrigatório');
  if(!Number.isFinite(amount) || amount<=0) throw new Error('Valor inválido');

  return { date, description, categoryId, type, amount };
}

function clearTxForm(){
  qs('#tx-desc').value = '';
  qs('#tx-amount').value = '';
  qs('#tx-desc').focus();
}

function setupTxForm(){
  const form = qs('#tx-form');
  if(!form) return;
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    try{
      const data = readTxForm();
      await addTx({ id: uuid(), ...data });
      showToast('Lançamento adicionado.');
      clearTxForm();
      // refresh é disparado por tx:changed, mas chamamos a tabela direto para feedback mais rápido
      refreshTxTable();
      refreshDashboard();
    }catch(err){
      console.error(err);
      showToast(err.message || 'Erro ao salvar');
    }
  });
}

/* ====== Filtros — eventos ====== */
function setupFilters(){
  const month = qs('#tx-filter-month');
  const text  = qs('#tx-search');
  const cat   = qs('#tx-filter-category');
  const type  = qs('#tx-filter-type');

  month?.addEventListener('change', ()=>{
    txFilters.month = month.value || txFilters.month;
    refreshTxTable(); refreshDashboard();
  });
  text?.addEventListener('input', ()=>{
    txFilters.text = text.value || '';
    refreshTxTable();
  });
  cat?.addEventListener('change', ()=>{
    txFilters.categoryId = cat.value || 'all';
    refreshTxTable();
  });
  type?.addEventListener('change', ()=>{
    txFilters.type = type.value || 'all';
    refreshTxTable();
  });
}

/* ====== Ações da tabela: duplicar / excluir ====== */
function setupTableActions(){
  const table = qs('#tx-table');
  if(!table) return;

  table.addEventListener('click', async (e)=>{
    const btn = e.target.closest('button[data-action]');
    if(!btn) return;
    const id = btn.getAttribute('data-id');
    const action = btn.getAttribute('data-action');

    // precisamos recuperar a transação pelo mês atual e id
    const {y,m} = getFilterMonth();
    const txs = await getTxByMonth(y,m);
    const tx = txs.find(t=>t.id===id);
    if(!tx) return;

    if(action==='del'){
      const ok = confirm('Excluir este lançamento?');
      if(!ok) return;
      await deleteTx(id);
      showToast('Lançamento excluído.');
      refreshTxTable(); refreshDashboard();
    }
    if(action==='dup'){
      const dup = { ...tx, id: uuid(), description: `${tx.description} (cópia)` };
      await addTx(dup);
      showToast('Lançamento duplicado.');
      refreshTxTable(); refreshDashboard();
    }
    // if(action==='edit'){ // deixamos para a próxima etapa (modal)
    // }
  });
}

/* ====== Inicialização local ====== */
function initTransactionsUI(){
  setDefaultDates();
  loadCategoriesIntoSelects();
  setupTxForm();
  setupFilters();
  setupTableActions();
  refreshTxTable(); // primeiro render
}

/* ====== Reagir a eventos globais ====== */
eventBus.on('db:ready',     ()=>{ initTransactionsUI(); refreshDashboard(); });
eventBus.on('tx:changed',   ()=>{ refreshTxTable(); refreshDashboard(); });
eventBus.on('cat:changed',  ()=>{ loadCategoriesIntoSelects(); refreshTxTable(); });
eventBus.on('ui:tab', (tab)=>{ if(tab==='lancamentos'){ /* foco rápido se quiser */ } });

// Se o DB já estiver carregado quando este arquivo entrar
if (window.dbRef){ initTransactionsUI(); refreshDashboard(); }

/* ===================== Seleção em massa ===================== */

/** Conjunto com os IDs selecionados no mês atual */
const selectedTxIds = new Set();

function clearSelection(){
  selectedTxIds.clear();
  updateBulkUI();
  // desmarca o mestre
  const master = qs('#tx-select-all');
  if(master) master.checked = false;
}

/** Atualiza contagem e habilita/desabilita botões */
function updateBulkUI(){
  const count = selectedTxIds.size;
  const el = qs('#bulk-count'); if(el) el.textContent = `${count} selecionado${count===1?'':'s'}`;
  const dup = qs('#bulk-dup'); const del = qs('#bulk-del'); const exp = qs('#bulk-export');
  if(dup) dup.disabled = count===0;
  if(del) del.disabled = count===0;
  if(exp) exp.disabled = count===0; // habilita/desabilita Exportar CSV
}

/** Marca checkboxes de linha conforme seleção atual (após re-render) */
function syncRowChecks(){
  qsa('#tx-table tbody input.tx-check').forEach(cb=>{
    const id = cb.getAttribute('data-id');
    cb.checked = selectedTxIds.has(id);
  });
  updateBulkUI();
}

/** Estende renderTxRows para incluir checkbox na 1ª coluna */
const _renderTxRows = renderTxRows;
renderTxRows = function(txs, cats){
  const tbody = qs('#tx-table tbody');
  if(!tbody) return;

  // delega para nossa versão adaptada
  tbody.innerHTML = '';
  if(txs.length===0){
    const tr = document.createElement('tr');
    const td = document.createElement('td'); td.colSpan=7; td.textContent='Nenhum lançamento encontrado.';
    tr.appendChild(td); tbody.appendChild(tr); clearSelection(); return;
  }

  const getCat = categoryLookup(cats);
  const frag = document.createDocumentFragment();

  for(const t of txs){
    const c = getCat(t.categoryId);
    const tr = document.createElement('tr');

    // Checkbox
    const tdSel = document.createElement('td');
    tdSel.innerHTML = `<input type="checkbox" class="tx-check" data-id="${t.id}" aria-label="Selecionar lançamento">`;

    const tdDate = document.createElement('td'); tdDate.textContent = formatDMY(t.date);
    const tdDesc = document.createElement('td'); tdDesc.textContent = t.description||'—';

    const tdCat = document.createElement('td');
    tdCat.innerHTML = `
      <span class="badge cat">
        <i class="fa-solid ${c?.icon||'fa-tag'}" style="color:${c?.color||'inherit'}"></i>
        ${c?.name||'Sem categoria'}
      </span>
    `;

    const tdType = document.createElement('td'); tdType.textContent = t.type==='income'?'Receita':'Despesa';
    const tdAmount = document.createElement('td'); tdAmount.style.fontWeight='700'; tdAmount.textContent = toBRL(t.amount||0);

    const tdActions = document.createElement('td');
    tdActions.className='row-actions';
    tdActions.innerHTML = `
      <button class="btn" data-action="dup" data-id="${t.id}" title="Duplicar"><i class="fa-solid fa-copy"></i></button>
      <button class="btn" data-action="del" data-id="${t.id}" title="Excluir"><i class="fa-solid fa-trash"></i></button>
    `;

    tr.append(tdSel, tdDate, tdDesc, tdCat, tdType, tdAmount, tdActions);
    frag.appendChild(tr);
  }
  tbody.appendChild(frag);

  // Reaplica estado de seleção
  syncRowChecks();
};

/** Eventos: checkbox mestre */
function setupBulkMaster(){
  const master = qs('#tx-select-all');
  if(!master) return;
  master.addEventListener('change', ()=>{
    selectedTxIds.clear();
    if(master.checked){
      // seleciona todos os IDs visíveis
      qsa('#tx-table tbody input.tx-check').forEach(cb=>{
        selectedTxIds.add(cb.getAttribute('data-id'));
        cb.checked = true;
      });
    }else{
      qsa('#tx-table tbody input.tx-check').forEach(cb=> cb.checked = false);
    }
    updateBulkUI();
  });
}

/** Eventos: checkboxes por linha (delegação) */
function setupBulkRowChecks(){
  const tbody = qs('#tx-table tbody');
  if(!tbody) return;
  tbody.addEventListener('change', (e)=>{
    const cb = e.target;
    if(!(cb instanceof HTMLInputElement) || !cb.classList.contains('tx-check')) return;
    const id = cb.getAttribute('data-id');
    if(!id) return;

    if(cb.checked) selectedTxIds.add(id);
    else selectedTxIds.delete(id);

    // atualiza mestre (marcado se todos estiverem marcados)
    const all = qsa('#tx-table tbody input.tx-check');
    const checked = all.filter(x=>x.checked).length;
    const master = qs('#tx-select-all');
    if(master) master.checked = (all.length>0 && checked===all.length);

    updateBulkUI();
  });
}

/** Eventos: botões de ação em massa */
function setupBulkButtons(){
  qs('#bulk-dup')?.addEventListener('click', async ()=>{
    if(selectedTxIds.size===0) return;
    const { y, m } = getFilterMonth();
    const source = await getTxByMonth(y,m);
    const toDup = source.filter(t=> selectedTxIds.has(t.id));
    for(const t of toDup){
      const dup = { ...t, id: uuid(), description: `${t.description} (cópia)` };
      await addTx(dup);
    }
    showToast(`${toDup.length} lançamento(s) duplicado(s).`);
    clearSelection();
    refreshTxTable(); refreshDashboard();
  });

  qs('#bulk-del')?.addEventListener('click', async ()=>{
    if(selectedTxIds.size===0) return;
    const ok = confirm(`Excluir ${selectedTxIds.size} lançamento(s)?`);
    if(!ok) return;
    const ids = Array.from(selectedTxIds);
    for(const id of ids){ await deleteTx(id); }
    showToast(`${ids.length} lançamento(s) excluído(s).`);
    clearSelection();
    refreshTxTable(); refreshDashboard();
  });
}

/** Reconfigura seleção ao inicializar e quando filtros mudam */
function initBulkSelection(){
  clearSelection();
  setupBulkMaster();
  setupBulkRowChecks();
  setupBulkButtons();
  setupBulkExport(); // <<< liga o Exportar CSV (selecionados)
}

/* Integra com ciclo de vida existente */
eventBus.on('db:ready',     initBulkSelection);
eventBus.on('tx:changed',   ()=>{ /* mantém seleção do que ainda aparece */ syncRowChecks(); updateBulkUI(); });
eventBus.on('ui:tab', (tab)=>{ if(tab==='lancamentos'){ syncRowChecks(); updateBulkUI(); } });

// Quando o script carregar com DB já pronto
if (window.dbRef){ initBulkSelection(); }

/* ===================== Exportar CSV (selecionados) ===================== */

/** Escapa campos para CSV: aspas duplas, vírgulas, quebras de linha */
function csvEscape(val){
  if(val===null || val===undefined) return '';
  const s = String(val);
  if(/[",\r\n;]/.test(s)){ // também cobre ; caso o usuário abra no Excel PT
    return `"${s.replace(/"/g,'""')}"`;
  }
  return s;
}

/** Gera CSV com cabeçalhos: date,description,category,type,amount */
async function buildSelectedCSV(){
  const count = selectedTxIds.size;
  if(count===0) return '';

  const { y, m } = getFilterMonth();
  const [txs, cats] = await Promise.all([ getTxByMonth(y,m), listCategories() ]);
  const getCat = categoryLookup(cats);

  const selected = txs.filter(t => selectedTxIds.has(t.id));
  // Cabeçalho
  const rows = [['date','description','category','type','amount']];

  for(const t of selected){
    const c = getCat(t.categoryId);
    rows.push([
      t.date,                                    // YYYY-MM-DD
      t.description || '',                       // texto cru
      c?.name || '',                             // nome da categoria
      t.type,                                    // income|expense
      (t.amount ?? 0)                            // número (ponto decimal)
    ]);
  }

  // Monta CSV (separador vírgula, \r\n por compatibilidade)
  const lines = rows.map(r => r.map(csvEscape).join(','));
  return lines.join('\r\n');
}

/** Handler do botão Exportar CSV */
function setupBulkExport(){
  const btn = qs('#bulk-export');
  if(!btn) return;
  btn.addEventListener('click', async ()=>{
    if(selectedTxIds.size===0) return;
    const { y, m } = getFilterMonth();
    const csv = await buildSelectedCSV();
    const filename = `lancamentos-selecionados-${y}-${String(m).padStart(2,'0')}.csv`;
    download(filename, csv);
    showToast('CSV exportado.');
  });
}
/* ===================== Modal de Edição ===================== */
const modalEl = document.getElementById('tx-modal');
const modalForm = document.getElementById('tx-edit-form');

function openModal(){
  if(!modalEl) return;
  modalEl.hidden = false;
  // trap de foco simples: foca no primeiro campo
  setTimeout(()=> document.getElementById('txm-date')?.focus(), 0);
  document.addEventListener('keydown', escClose);
}
function closeModal(){
  if(!modalEl) return;
  modalEl.hidden = true;
  document.removeEventListener('keydown', escClose);
}
function escClose(e){ if(e.key==='Escape') closeModal(); }

// fechar ao clicar em backdrop/botões
modalEl?.addEventListener('click', (e)=>{
  if(e.target.matches('[data-modal-close]')) closeModal();
});

// preenche select de categorias do modal
async function fillModalCategories(){
  const cats = await listCategories();
  const sel = document.getElementById('txm-category');
  if(sel){
    sel.innerHTML = cats.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
  }
}

// carrega dados no modal a partir do ID
async function loadTxIntoModal(id){
  const { y, m } = getFilterMonth();
  const txs = await getTxByMonth(y,m);
  const tx = txs.find(t=>t.id===id);
  if(!tx) return;

  await fillModalCategories();

  document.getElementById('txm-id').value = tx.id;
  document.getElementById('txm-date').value = tx.date;
  document.getElementById('txm-desc').value = tx.description || '';
  document.getElementById('txm-category').value = tx.categoryId || '';
  document.getElementById('txm-type').value = tx.type || 'expense';
  document.getElementById('txm-amount').value = (tx.amount ?? 0);
  openModal();
}

// intercepta clique em “Editar”
(function hookEditButton(){
  const table = qs('#tx-table');
  if(!table) return;
  table.addEventListener('click', async (e)=>{
    const btn = e.target.closest('button[data-action="edit"]');
    if(!btn) return;
    const id = btn.getAttribute('data-id');
    await loadTxIntoModal(id);
  });
})();

// salvar alterações do modal
modalForm?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  try{
    const id = document.getElementById('txm-id').value;
    const date = document.getElementById('txm-date').value;
    const description = document.getElementById('txm-desc').value.trim();
    const categoryId = document.getElementById('txm-category').value;
    const type = document.getElementById('txm-type').value;
    const amount = parseBRNumber(document.getElementById('txm-amount').value);

    if(!id) throw new Error('ID inválido');
    if(!date) throw new Error('Data obrigatória');
    if(!description) throw new Error('Descrição obrigatória');
    if(!categoryId) throw new Error('Categoria obrigatória');
    if(!type) throw new Error('Tipo obrigatório');
    if(!Number.isFinite(amount) || amount<=0) throw new Error('Valor inválido');

    await updateTx({ id, date, description, categoryId, type, amount });
    closeModal();
    showToast('Lançamento atualizado.');
    refreshTxTable();
    refreshDashboard();
  }catch(err){
    console.error(err);
    showToast(err.message || 'Erro ao salvar edição');
  }
});
/* =========================================================
   [PATCH] Garantir opções no <select> de categoria
   - Preenche: #tx-category (form Novo lançamento)
   - (Opcional) #filter-category (filtros da tabela), se existir
   - Mantém "placeholder" no topo
   - Atualiza em db:ready e cat:changed
   ========================================================= */

async function hydrateCategorySelects() {
  // 1) Busca categorias
  let cats = [];
  try {
    cats = await listCategories(); // vem do db.js
  } catch (e) {
    console.error('[hydrateCategorySelects] Erro ao listar categorias:', e);
    return;
  }

  // Mantém uma ordem estável (alfabética)
  cats.sort((a,b)=> a.name.localeCompare(b.name,'pt-BR'));

  // 2) Monta <option>s (podemos filtrar "Renda" do form de despesas, se desejar)
  const makeOptions = (withPlaceholder=true, excludeIncome=false) => {
    const frag = document.createDocumentFragment();
    if (withPlaceholder) {
      const opt0 = document.createElement('option');
      opt0.value = '';
      opt0.textContent = 'Selecione...';
      frag.appendChild(opt0);
    }
    for (const c of cats) {
      // `excludeIncome` é útil se você não quiser "Renda" como opção ao lançar despesas.
      if (excludeIncome && c.name.toLowerCase() === 'renda') continue;
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      frag.appendChild(opt);
    }
    return frag;
  };

  // 3) Preenche o select do formulário de novo lançamento (#tx-category)
  const txCat = document.querySelector('#tx-category');
  if (txCat) {
    const current = txCat.value;       // preserva a seleção atual, se houver
    txCat.innerHTML = '';              // limpa
    txCat.appendChild(makeOptions(true, /*excludeIncome=*/false));
    // restaura seleção se ainda existir
    if (current && [...txCat.options].some(o => o.value === current)) {
      txCat.value = current;
    }
  }

  // 4) (Opcional) Preenche o select de filtro, se existir (#filter-category)
  const filterCat = document.querySelector('#filter-category');
  if (filterCat) {
    const current = filterCat.value;
    filterCat.innerHTML = '';
    filterCat.appendChild(makeOptions(true, /*excludeIncome=*/false));
    if (current && [...filterCat.options].some(o => o.value === current)) {
      filterCat.value = current;
    }
  }

  // 5) Também podemos atualizar o select de regras (#rule-category) se ele estiver na página
  const ruleCat = document.querySelector('#rule-category');
  if (ruleCat) {
    const current = ruleCat.value;
    ruleCat.innerHTML = '';
    ruleCat.appendChild(makeOptions(true, /*excludeIncome=*/false));
    if (current && [...ruleCat.options].some(o => o.value === current)) {
      ruleCat.value = current;
    }
  }
}

// Liga nos eventos do app
eventBus.on('db:ready', hydrateCategorySelects);
eventBus.on('cat:changed', hydrateCategorySelects);

// Fallback: se o script carregar depois do DB já aberto
if (window.dbRef) {
  hydrateCategorySelects();
}
/* =========================================================
   Hidratação garantida dos <select> de categorias
   (Novo lançamento, Filtros, Regras)
   ========================================================= */

async function __bw_fetchCategoriesSorted() {
  try {
    const cats = await listCategories();
    return (cats || []).sort((a,b) => a.name.localeCompare(b.name, 'pt-BR'));
  } catch (e) {
    console.error('[categories select] listCategories falhou:', e);
    return [];
  }
}

function __bw_buildOptions(cats, { placeholder = 'Selecione...' } = {}) {
  const frag = document.createDocumentFragment();

  if (placeholder !== false) {
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = placeholder;
    frag.appendChild(opt0);
  }

  for (const c of cats) {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = c.name;
    frag.appendChild(opt);
  }
  return frag;
}

async function populateCategorySelect(selectEl, catsCache = null) {
  if (!selectEl) return;
  const current = selectEl.value;
  const cats = catsCache || await __bw_fetchCategoriesSorted();

  selectEl.innerHTML = '';
  selectEl.appendChild(__bw_buildOptions(cats));

  // restaura seleção se ainda existir
  if (current && [...selectEl.options].some(o => o.value === current)) {
    selectEl.value = current;
  }
}

async function refreshAllCategorySelects() {
  const cats = await __bw_fetchCategoriesSorted();

  const selectors = [
    '#tx-category',
    '#filter-category',
    '#rule-category',
    'select[data-cat-select]',
    'select[name="categoryId"]',
    'select[name="category"]'
  ];

  const all = [...document.querySelectorAll(selectors.join(','))];
  await Promise.all(all.map(sel => populateCategorySelect(sel, cats)));
}

// Reidrata quando o DB abre e quando categorias mudam
eventBus.on('db:ready', refreshAllCategorySelects);
eventBus.on('cat:changed', refreshAllCategorySelects);

// Fallback: se o script carregar depois do DB já ter aberto
if (window.dbRef) {
  refreshAllCategorySelects();
}

// (opcional) helper visível no console para depurar
window.__debugListCats = () => listCategories().then(cs => console.table(cs));
// path: budgetwave/scripts/transactions.js  (PATCH — logo após o boot/código que inicializa a aba)
document.addEventListener('DOMContentLoaded', () => {
  // ... seu código existente de inicialização ...

  // Garante que o select de "Novo lançamento" esteja hidratado mesmo
  // se a aba ainda não tiver sido visitada
  if (window.hydrateCategorySelects) {
    window.hydrateCategorySelects();
  }
});
