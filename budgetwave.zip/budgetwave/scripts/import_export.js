// path: budgetwave/scripts/import_export.js
/* Importação CSV (mapeável + preview) e Backup/Restore (JSON de todas as stores) */
(function(){
  // ===== CSV =====
  function guessDelimiter(text){
    // conta separadores por linha e estima
    const lines = text.split(/\r?\n/).slice(0,10);
    const counts = { ',':0, ';':0, '\t':0, '|':0 };
    for(const ln of lines){
      for(const d of Object.keys(counts)){
        counts[d] += (ln.split(d).length - 1);
      }
    }
    // escolhe o de maior contagem (fallback ',')
    return Object.entries(counts).sort((a,b)=> b[1]-a[1])[0]?.[0] || ',';
  }

  function parseCSV(text){
    const delim = guessDelimiter(text);
    const rows = text.split(/\r?\n/).map(l=> l.trim()).filter(Boolean);
    const table = rows.map(line=>{
      // parse simples (sem aspas escapadas complexas); suficiente p/ nosso uso
      return line.split(delim).map(x=> x.replace(/^"(.*)"$/,'$1').trim());
    });
    return { delim, header: table[0]||[], rows: table.slice(1) };
  }

  // monta selects de mapeamento
  function fillMapSelect(select, header, preferred){
    select.innerHTML = '';
    const optNone = document.createElement('option');
    optNone.value = '';
    optNone.textContent = '-- selecione --';
    select.appendChild(optNone);
    header.forEach((h,i)=>{
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = h || `col${i+1}`;
      select.appendChild(o);
    });
    if(preferred!=null){
      const idx = header.findIndex(h=> h && h.toLowerCase().includes(preferred));
      if(idx>=0) select.value = String(idx);
    }
  }

  function fillAllMapControls(header){
    fillMapSelect(document.getElementById('map-date'), header, 'data');
    fillMapSelect(document.getElementById('map-desc'), header, 'descr');
    fillMapSelect(document.getElementById('map-cat'),  header, 'categ');
    fillMapSelect(document.getElementById('map-type'), header, 'tipo');
    fillMapSelect(document.getElementById('map-amount'),header, 'valor');
  }

  // preview tabela
  function renderCSVPreview(header, rows){
    const thead = document.getElementById('csv-preview-head');
    const tbody = document.getElementById('csv-preview-body');
    if(!thead || !tbody) return;

    thead.innerHTML = header.map(h=> `<th>${escapeHtml(h||'—')}</th>`).join('');
    tbody.innerHTML = '';

    const frag = document.createDocumentFragment();
    rows.slice(0,50).forEach(r=>{
      const tr = document.createElement('tr');
      tr.innerHTML = r.map(c=> `<td>${escapeHtml(c||'')}</td>`).join('');
      frag.appendChild(tr);
    });
    tbody.appendChild(frag);
  }

  // normalizações
  function toISODate(s){
    // tenta YYYY-MM-DD ou DD/MM/YYYY
    const t = s.trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(t)) return t;
    const m = t.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if(m) return `${m[3]}-${m[2]}-${m[1]}`;
    return ''; // inválida
  }
  function toBRNumberSafe(s){
    if(s==null) return NaN;
    const t = String(s).trim()
      .replace(/\./g,'')      // remove separador milhar
      .replace(',','.')       // vírgula decimal
      .replace(/[^\d.-]/g,''); // qualquer lixo
    return Number(t);
  }

  async function importCSVRows(header, rows){
    // lê mapeamento
    const idxDate   = Number(document.getElementById('map-date')?.value||'');
    const idxDesc   = Number(document.getElementById('map-desc')?.value||'');
    const idxCat    = document.getElementById('map-cat')?.value;
    const idxType   = Number(document.getElementById('map-type')?.value||'');
    const idxAmount = Number(document.getElementById('map-amount')?.value||'');

    if(!Number.isFinite(idxDate) || !Number.isFinite(idxDesc) || !Number.isFinite(idxType) || !Number.isFinite(idxAmount)){
      showToast('Mapeamento incompleto.'); return;
    }

    const cats = await listCategories();
    const catsName = new Map(cats.map(c=>[normalizeText(c.name), c]));
    const byId = new Map(cats.map(c=>[c.id, c]));

    // regras automáticas
    const rules = (await getSetting('rules')) || [];

    let imported = 0, failed = 0;
    for(const r of rows){
      const date = toISODate(r[idxDate]||'');
      const desc = String(r[idxDesc]||'').trim();
      const typeRaw = String(r[idxType]||'').toLowerCase().trim();
      const amount = toBRNumberSafe(r[idxAmount]);
      if(!date || !desc || !Number.isFinite(amount) || amount<=0) { failed++; continue; }

      let type = (typeRaw.includes('receita') || typeRaw==='income') ? 'income' : 'expense';

      // categoria: por CSV (se mapeado) OU por regras OU vazio
      let categoryId = '';
      if(idxCat && idxCat !== ''){
        const raw = String(r[Number(idxCat)]||'').trim();
        const byName = catsName.get(normalizeText(raw));
        if(byName) categoryId = byName.id;
      }
      if(!categoryId && rules.length){
        // aplica regras no preview/import
        const ndesc = normalizeText(desc);
        for(const rule of rules){
          if(rule.keywords.some(kw => ndesc.includes(kw))){
            categoryId = rule.categoryId; break;
          }
        }
      }
      // fallback: se for receita e existir categoria "Renda"
      if(!categoryId && type==='income'){
        const renda = catsName.get(normalizeText('Renda'));
        if(renda) categoryId = renda.id;
      }

      try{
        await addTx({ id: uuid(), date, description: desc, categoryId, type, amount: Math.abs(amount) });
        imported++;
      }catch{ failed++; }
    }

    showToast(`Importação concluída: ${imported} ok, ${failed} falhas.`);
    eventBus.dispatch('tx:changed');
  }

  // handlers UI
  let _csvCache = null;
  document.getElementById('csv-parse')?.addEventListener('click', async ()=>{
    const file = document.getElementById('csv-file')?.files?.[0];
    if(!file){ showToast('Selecione um arquivo CSV.'); return; }
    const text = await file.text();
    const { header, rows } = parseCSV(text);
    if(!header.length){ showToast('Cabeçalho não encontrado.'); return; }
    _csvCache = { header, rows };

    document.getElementById('csv-map').hidden = false;
    fillAllMapControls(header);
    renderCSVPreview(header, rows);
    showToast('Pré-visualização pronta. Faça o mapeamento e clique em Importar.');
  });

  document.getElementById('csv-import')?.addEventListener('click', async ()=>{
    if(!_csvCache){ showToast('Pré-visualize o CSV primeiro.'); return; }
    await importCSVRows(_csvCache.header, _csvCache.rows);
  });

  // ===== Backup / Restore =====
  async function exportBackupJSON(){
    // lê tudo das stores
    const [txs, cats, theme, rules, salary, goalProfile] = await Promise.all([
      getAllFromStore('transactions'),
      getAllFromStore('categories'),
      getSetting('theme'),
      getSetting('rules'),
      getSetting('salary'),
      getSetting('goalProfile'),
    ]);

    const payload = {
      version: 1,
      timestamp: new Date().toISOString(),
      transactions: txs || [],
      categories: cats || [],
      settings: {
        theme: theme ?? 'dark',
        rules: rules || [],
        salary: salary ?? null,
        goalProfile: goalProfile || null
      }
    };

    const json = JSON.stringify(payload, null, 2);
    const a = document.createElement('a');
    a.download = `budgetwave_backup_${Date.now()}.json`;
    a.href = URL.createObjectURL(new Blob([json], {type:'application/json'}));
    a.click();
    setTimeout(()=> URL.revokeObjectURL(a.href), 1000);
  }

  async function importBackupJSON(file){
    const text = await file.text();
    let data = null;
    try{ data = JSON.parse(text); }catch{ showToast('JSON inválido.'); return; }
    if(!data || !Array.isArray(data.transactions) || !Array.isArray(data.categories) || !data.settings){
      showToast('Backup incompatível.'); return;
    }

    // substitui stores por completo
    await clearStore('transactions');
    await clearStore('categories');
    for(const t of data.transactions){
      // sanity: ajusta campos mínimos
      if(!t.id) t.id = uuid();
      await addTx(t);
    }
    for(const c of data.categories){
      if(!c.id) c.id = uuid();
      await addCategory(c);
    }
    // settings
    const s = data.settings || {};
    if('theme' in s) await setSetting('theme', s.theme);
    if('rules' in s) await setSetting('rules', s.rules||[]);
    if('salary' in s) await setSetting('salary', s.salary??null);
    if('goalProfile' in s) await setSetting('goalProfile', s.goalProfile||null);

    showToast('Backup restaurado com sucesso.');
    eventBus.dispatch('cat:changed');
    eventBus.dispatch('tx:changed');
    eventBus.dispatch('settings:changed');
  }

  document.getElementById('backup-export')?.addEventListener('click', exportBackupJSON);
  document.getElementById('backup-import')?.addEventListener('change', (e)=>{
    const f = e.target.files?.[0];
    if(f) importBackupJSON(f);
    e.target.value = ''; // permite re-selecionar o mesmo arquivo depois
  });

  // helpers usando db.js
  async function getAllFromStore(storeName){
    return new Promise((resolve,reject)=>{
      const tx = dbRef.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = ()=> resolve(req.result || []);
      req.onerror = reject;
    });
  }
  async function clearStore(storeName){
    return new Promise((resolve,reject)=>{
      const tx = dbRef.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.clear();
      req.onsuccess = ()=> resolve();
      req.onerror = reject;
    });
  }
})();
/* BudgetWave – Importação CSV (mapeável) + Backup/Restore JSON
   -------------------------------------------------------------
   Requisitos de integração:
   - db.js: window.dbRef, addTx(tx), listCategories(), getSetting/setSetting
   - transactions.js: applyAutoRules(desc)  (se não existir, caímos em um fallback)
   - utils.js: uuid(), toBRL(), parseBRNumber(), normalizeText(), formatDateYYYYMMDD()
   - state.js: eventBus (on/dispatch)
*/

(function(){
  // ========== Config de seletores (ajuste se seu HTML tiver IDs diferentes) ==========
  const SELECTORS = {
    csvFile:          '#csv-file',            // <input type="file">
    csvPreviewBtn:    '#csv-preview',         // botão "Pré-visualizar"
    csvImportBtn:     '#csv-import',          // botão "Importar"
    csvMapWrap:       '#csv-map',             // container onde renderizamos selects de mapeamento
    csvPreviewWrap:   '#csv-preview-table',   // container da tabela de preview
    csvHint:          '#csv-hint',            // texto de dicas (opcional)

    backupExportBtn:  '#btn-export-backup',   // botão "Exportar backup (JSON)"
    backupImportFile: '#backup-file',         // input file (JSON)
    backupImportBtn:  '#btn-import-backup',   // botão "Restaurar backup (JSON)"
  };

  // ========== Helpers DOM / Toast ==========
  const qs  = (s, el=document) => el.querySelector(s);
  const qsa = (s, el=document) => [...el.querySelectorAll(s)];
  function h(html){ const t=document.createElement('template'); t.innerHTML=html.trim(); return t.content.firstElementChild; }
  function showToast(msg){ const t=window.showToast ? window.showToast : (m)=>alert(m); t(msg); }

  // ========== CSV ==========
  function guessDelimiter(text){
    // Conta ocorrências por linha das opções, escolhe a que tem maior consistência
    const first = text.split(/\r?\n/).slice(0, 5);
    const candidates = [',',';','\t'];
    let best = ',', bestScore = -1;
    for(const d of candidates){
      const counts = first.map(l => (l.match(new RegExp(`\\${d}`, 'g'))||[]).length);
      const avg = counts.reduce((a,b)=>a+b,0) / Math.max(counts.length,1);
      if (avg > bestScore){ bestScore = avg; best = d; }
    }
    return best;
  }

  function parseCSV(text, delimiter){
    const d = delimiter || guessDelimiter(text);
    const lines = text.replace(/\r/g,'').split('\n').filter(l=>l.trim().length);
    const rows = lines.map(line => {
      // separador simples; atende CSVs comuns (sem aspas aninhadas)
      return line.split(d).map(c => c.trim());
    });
    return { delimiter: d, header: rows[0] || [], rows: rows.slice(1) };
  }

  // ========== Normalização ==========
  function toYYYYMMDD(val){
    // aceita "YYYY-MM-DD" ou "DD/MM/YYYY"
    if(!val) return null;
    const s = String(val).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
    if (m){
      const dd = String(m[1]).padStart(2,'0');
      const mm = String(m[2]).padStart(2,'0');
      let yy = String(m[3]);
      if (yy.length===2) yy = '20'+yy;
      return `${yy}-${mm}-${dd}`;
    }
    return null;
  }
  function toNumberBR(n){
    if(n==null || n==='') return null;
    if (typeof n === 'number') return n;
    const s = String(n).replace(/\./g,'').replace(',','.');
    const v = Number(s);
    return Number.isFinite(v) ? v : null;
  }

  async function getCategoriesByName(){
    const cats = await listCategories();
    const map = new Map();
    for(const c of (cats||[])){
      map.set(normalizeText(c.name), c);
    }
    return map;
  }

  async function applyRulesIfAny(description, categoryId){
    if (categoryId) return categoryId;
    const desc = normalizeText(description||'');
    // tenta usar applyAutoRules do transactions.js se existir
    if (typeof window.applyAutoRules === 'function'){
      const maybe = await window.applyAutoRules(desc);
      return maybe || '';
    }
    // fallback: ler settings.rules e checar keywords
    const rules = (await getSetting('rules')) || [];
    for(const r of rules){
      if (!r || !r.keywords || !r.categoryId) continue;
      const hit = (r.keywords||[]).some(k => desc.includes(normalizeText(k)));
      if (hit) return r.categoryId;
    }
    return '';
  }

  // ========== Mapeamento UI ==========
  const MAP_FIELDS = [
    { key:'date',        label:'Data' },
    { key:'description', label:'Descrição' },
    { key:'category',    label:'Categoria' },
    { key:'type',        label:'Tipo (Receita/Despesa)' },
    { key:'amount',      label:'Valor' },
  ];

  function renderMapUI(headers){
    const wrap = qs(SELECTORS.csvMapWrap);
    if(!wrap) return;
    wrap.innerHTML = '';
    const group = h(`<div class="csv-map"><div class="csv-map__controls"></div></div>`);
    const controls = qs('.csv-map__controls', group);

    MAP_FIELDS.forEach(f=>{
      const sel = h(`
        <label>
          <span>${f.label}</span>
          <select data-map="${f.key}">
            <option value="">(não importar)</option>
            ${headers.map(hh => `<option value="${hh}">${hh}</option>`).join('')}
          </select>
        </label>
      `);
      controls.appendChild(sel);
    });

    wrap.appendChild(group);
  }

  function getMapSelection(){
    const sel = {};
    MAP_FIELDS.forEach(f=>{
      const el = qs(`select[data-map="${f.key}"]`);
      sel[f.key] = el ? el.value : '';
    });
    return sel;
  }

  // ========== Preview ==========
  function renderPreviewTable(items){
    const wrap = qs(SELECTORS.csvPreviewWrap);
    if(!wrap) return;
    if(!items.length){
      wrap.innerHTML = `<div class="csv-preview muted">Nenhuma linha válida.</div>`;
      return;
    }
    const head = `<thead><tr>
      <th>Data</th><th>Descrição</th><th>Categoria</th><th>Tipo</th><th style="text-align:right">Valor</th>
    </tr></thead>`;
    const body = items.slice(0, 50).map(it => `
      <tr>
        <td>${it.date||'—'}</td>
        <td>${escapeHtml(it.description||'')}</td>
        <td>${escapeHtml(it.categoryName||'')}</td>
        <td>${it.type||'—'}</td>
        <td style="text-align:right">${toBRL(it.amount||0)}</td>
      </tr>
    `).join('');
    wrap.innerHTML = `
      <div class="table-wrap">
        <table class="table">
          ${head}
          <tbody>${body}</tbody>
        </table>
      </div>
    `;
  }

  // ========== Fluxo Preview/Import ==========
  let __lastParsed = null;
  let __lastPreview = [];

  async function handlePreview(){
    const file = qs(SELECTORS.csvFile)?.files?.[0];
    if(!file){ showToast('Selecione um arquivo CSV.'); return; }
    const text = await file.text();
    const parsed = parseCSV(text);
    __lastParsed = parsed;

    if (!parsed.header.length){
      showToast('CSV inválido ou vazio.');
      return;
    }

    renderMapUI(parsed.header);
    // tenta um mapeamento inicial “esperto”
    autoGuessMapping(parsed.header);

    // gera preview com base no mapeamento atual
    __lastPreview = await mapRowsToTxs(parsed.header, parsed.rows, getMapSelection());
    renderPreviewTable(__lastPreview);
    showToast('Pré-visualização gerada.');
  }

  function autoGuessMapping(headers){
    const mapBy = (kw) => headers.find(h => normalizeText(h).includes(kw)) || '';
    const set = (k, v) => { const el=qs(`select[data-map="${k}"]`); if(el) el.value=v; };

    set('date',        mapBy('data'));
    set('description', mapBy('descri'));
    set('category',    mapBy('categoria'));
    set('type',        mapBy('tipo'));
    set('amount',      mapBy('valor'));
  }

  async function mapRowsToTxs(header, rows, mapping){
    const idx = (col) => header.indexOf(mapping[col]);
    const idate=idx('date'), idesc=idx('description'), icat=idx('category'),
          itype=idx('type'), iamount=idx('amount');

    const catByName = await getCategoriesByName();

    const out = [];
    for(const r of rows){
      if(!r || !r.length) continue;

      const rawDate = idate>=0 ? r[idate] : '';
      const rawDesc = idesc>=0 ? r[idesc] : '';
      const rawCat  = icat>=0 ? r[icat]  : '';
      const rawType = itype>=0 ? r[itype] : '';
      const rawAmt  = iamount>=0 ? r[iamount] : '';

      const date = toYYYYMMDD(rawDate);
      const description = String(rawDesc||'').trim();
      const amount = toNumberBR(rawAmt);

      if(!date || !description || !Number.isFinite(amount)) continue;

      // categoria: por nome se existir; se não, tenta regras automáticas
      let categoryId = '';
      let categoryName = String(rawCat||'').trim();
      if(categoryName){
        const cat = catByName.get(normalizeText(categoryName));
        if(cat){ categoryId = cat.id; categoryName = cat.name; }
      }
      categoryId = await applyRulesIfAny(description, categoryId);
      if(!categoryName && categoryId){
        // preenche para aparecer no preview
        const cats = await listCategories();
        const found = (cats||[]).find(c=>c.id===categoryId);
        categoryName = found ? found.name : '';
      }

      // tipo: aceita income/expense ou Receita/Despesa
      let type = 'expense';
      const st = normalizeText(rawType||'');
      if (st.includes('receit')) type = 'income';
      if (st==='income') type='income';
      if (st==='expense') type='expense';

      out.push({
        id: uuid(),
        date, description, categoryId, categoryName, type, amount
      });
    }
    return out;
  }

  async function handleImport(){
    if(!__lastParsed){ showToast('Faça a pré-visualização antes.'); return; }
    const mapping = getMapSelection();
    const items = await mapRowsToTxs(__lastParsed.header, __lastParsed.rows, mapping);
    if(!items.length){ showToast('Nenhuma linha válida para importar.'); return; }

    // salva em série (ou em lote simples)
    for(const tx of items){
      await addTx({
        id: tx.id,
        date: tx.date,
        description: tx.description,
        categoryId: tx.categoryId || '',
        type: tx.type,
        amount: tx.amount,
      });
    }
    showToast(`Importado${items.length>1?'s':''}: ${items.length} lançamento${items.length>1?'s':''}.`);
    eventBus.dispatch('tx:changed');
  }

  // ========== Backup/Restore JSON ==========
  async function exportBackupJSON(){
    try{
      const data = await dumpAllStores();
      const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'});
      const a = document.createElement('a');
      const dt = new Date(); const tag = `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`;
      a.href = URL.createObjectURL(blob);
      a.download = `budgetwave-backup-${tag}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
      showToast('Backup exportado.');
    }catch(err){
      console.error(err);
      showToast('Falha ao exportar backup.');
    }
  }

  async function importBackupJSON(){
    const input = qs(SELECTORS.backupImportFile);
    const file = input?.files?.[0];
    if(!file){ showToast('Selecione um arquivo JSON.'); return; }
    let data = null;
    try{
      data = JSON.parse(await file.text());
    }catch(err){
      showToast('JSON inválido.'); return;
    }
    if(!data){ showToast('Backup vazio.'); return; }

    // merge incremental (ignora chaves duplicadas simples)
    const txs = data.transactions || [];
    const cats= data.categories  || [];
    const sets= data.settings    || [];

    for(const c of cats) { try{ await addCategory(c); }catch(e){} }
    for(const t of txs)  { try{ await addTx(t); }catch(e){} }
    for(const s of sets) { try{ await setSetting(s.key, s.value); }catch(e){} }

    showToast('Backup restaurado.');
    eventBus.dispatch('cat:changed');
    eventBus.dispatch('tx:changed');
    eventBus.dispatch('settings:changed');
  }

  async function dumpAllStores(){
    const db = window.dbRef;
    if(!db) throw new Error('DB não disponível');
    const stores = ['transactions','categories','settings'];
    const out = {};
    for(const st of stores){
      out[st] = await idbGetAll(db, st);
    }
    return out;
  }

  function idbGetAll(db, storeName){
    return new Promise((resolve, reject)=>{
      const tx = db.transaction(storeName, 'readonly');
      const st = tx.objectStore(storeName);
      const req = ('getAll' in st) ? st.getAll() : st.openCursor(); // fallback
      if (req && typeof req.onsuccess !== 'undefined'){
        req.onsuccess = (e)=>{
          if ('result' in req && Array.isArray(req.result)) resolve(req.result);
          else {
            // cursor fallback
            const arr = [];
            const cursor = e.target.result;
            if (!cursor) return resolve(arr);
          }
        };
        req.onerror = ()=>reject(req.error);
      }else{
        // cursor path
        const result = [];
        const openReq = st.openCursor();
        openReq.onsuccess = (e)=>{
          const cursor = e.target.result;
          if (cursor){ result.push(cursor.value); cursor.continue(); }
          else resolve(result);
        };
        openReq.onerror = ()=>reject(openReq.error);
      }
    });
  }

  // ========== Bind UI ==========
  function bindUI(){
    const $file  = qs(SELECTORS.csvFile);
    const $prev  = qs(SELECTORS.csvPreviewBtn);
    const $imp   = qs(SELECTORS.csvImportBtn);
    const $exb   = qs(SELECTORS.backupExportBtn);
    const $imf   = qs(SELECTORS.backupImportFile);
    const $imb   = qs(SELECTORS.backupImportBtn);

    if ($file && $prev){
      $prev.addEventListener('click', (e)=>{ e.preventDefault(); handlePreview(); });
    }
    if ($imp){
      $imp.addEventListener('click', (e)=>{ e.preventDefault(); handleImport(); });
    }
    if ($exb){
      $exb.addEventListener('click', (e)=>{ e.preventDefault(); exportBackupJSON(); });
    }
    if ($imb){
      $imb.addEventListener('click', (e)=>{ e.preventDefault(); importBackupJSON(); });
    }

    // se mudar o mapeamento, atualiza o preview ao vivo
    qs(SELECTORS.csvMapWrap)?.addEventListener('change', async (ev)=>{
      if(!__lastParsed) return;
      __lastPreview = await mapRowsToTxs(__lastParsed.header, __lastParsed.rows, getMapSelection());
      renderPreviewTable(__lastPreview);
    });
  }

  // Inicialização
  eventBus.on('db:ready', bindUI);
  if (window.dbRef) bindUI();

})();
