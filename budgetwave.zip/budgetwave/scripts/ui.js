// path: budgetwave/scripts/ui.js
// Helpers já existentes em utils.js: qs, qsa, showToast
qsa('.tab-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    qsa('.tab-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    qsa('.tab-panel').forEach(p=>p.classList.remove('active'));
    qs('#tab-'+tab).classList.add('active');
    setTab(tab);
    // fecha o menu mobile ao selecionar
    closeMobileMenu();
  });
});

// toggle tema
qs('#themeToggle').addEventListener('click', ()=>{
  setTheme(state.theme === 'dark' ? 'light' : 'dark');
  showToast(`Tema: ${state.theme === 'dark' ? 'Escuro' : 'Claro'}`);
});

// atalhos
document.addEventListener('keydown', (e)=>{
  if(e.key==='/' ){ e.preventDefault(); showToast('Atalho “/”: foco na busca (quando existir)'); }
  if(e.key==='g'){
    const handler=(ev)=>{
      if(ev.key==='d'){ triggerTab('dashboard'); cleanup(); }
      if(ev.key==='l'){ triggerTab('lancamentos'); cleanup(); }
      if(ev.key==='c'){ triggerTab('categorias'); cleanup(); }
      function cleanup(){ document.removeEventListener('keydown', handler); }
    };
    document.addEventListener('keydown', handler, {once:true});
  }
  if(e.key==='Escape'){ closeMobileMenu(); }
});

function triggerTab(tab){
  const b = qsa('.tab-btn').find(x=>x.dataset.tab===tab);
  b?.click();
}

/* ====== Menu Mobile ====== */
const header = qs('#appHeader');
const navToggle = qs('#navToggle');

function closeMobileMenu(){
  header.classList.remove('open');
  navToggle.setAttribute('aria-expanded','false');
  navToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
}
function openMobileMenu(){
  header.classList.add('open');
  navToggle.setAttribute('aria-expanded','true');
  navToggle.innerHTML = '<i class="fa-solid fa-xmark"></i>';
}

navToggle.addEventListener('click', ()=>{
  const open = header.classList.contains('open');
  open ? closeMobileMenu() : openMobileMenu();
});

window.addEventListener('resize', ()=>{
  if(window.innerWidth > 900){ closeMobileMenu(); }
});
// Atalho "/" foca a busca de lançamentos (se existir)
document.addEventListener('keydown', (e)=>{
  if(e.key==='/' && !/input|textarea|select/i.test(document.activeElement.tagName)){
    const s = document.getElementById('tx-search');
    if(s){ e.preventDefault(); s.focus(); s.select(); }
  }
  // "n" para começar novo lançamento (na aba Lançamentos)
  if(e.key==='n' && state.currentTab==='lancamentos'){
    e.preventDefault();
    document.getElementById('tx-desc')?.focus();
  }
});
// path: budgetwave/scripts/ui.js  (PATCH — acrescente na lógica de navegação de abas)
const BUS = window.eventBus;
// ... sua lógica existente ...
function activateTab(tabId) {
  // ... troca de classes/aria etc. ...
  BUS.emit('ui:tab', tabId);

  // Hidratação defensiva ao ativar abas que usam categorias
  if ((tabId === 'lancamentos' || tabId === 'config' || tabId === 'relatorios') && window.hydrateCategorySelects) {
    window.hydrateCategorySelects();
  }
}
