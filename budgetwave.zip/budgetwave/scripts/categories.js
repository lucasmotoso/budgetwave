// path: budgetwave/scripts/categories.js
/* Categorias + Metas (regra dos 10%)
   - CRUD de categorias (nome, cor, ícone, monthlyGoal)
   - Salário mensal (settings.salary)
   - Sugestão de metas: 10% reservado p/ poupança; 90% distribuível por perfil
   - Perfil ajustável com sliders (somam 90%) + preview dinâmico (R$ e progresso)
   - Progresso do mês (gasto / meta) por categoria
   - Hidratação única para todos os <select data-cat-select> (com placeholder opcional)
*/
(() => {
  const BUS = window.eventBus;
  const {
    qs, qsa, toBRL, parseBRNumber, uuid,
    normalizeText, showToast,
  } = window.Utils || {};

  /* ------------------ Constantes ------------------ */
  const GOAL_PROFILE = [
    ['Moradia',     30],
    ['Alimentação', 18],
    ['Mercado',     15],
    ['Transporte',  10],
    ['Saúde',        8],
    ['Educação',     7],
    ['Lazer',       12],
    // "Renda" não recebe meta
  ];

  /* ------------------ Helpers ------------------ */
  const escapeHtml = (s) =>
    String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  function getCurrentYM() {
    const d = new Date();
    return { y: d.getFullYear(), m: d.getMonth() + 1 };
  }

  /* ------------------ Form UX ------------------ */
  function resetCatForm() {
    qs('#cat-id')?.value = '';
    (qs('#cat-name') || {}).value = '';
    (qs('#cat-color') || {}).value = '#14b8a6';
    (qs('#cat-icon') || {}).value = '';
    (qs('#cat-goal') || {}).value = '';
    qs('#cat-name')?.focus();
    updateCatPreview();
  }

  function updateCatPreview() {
    const name  = qs('#cat-name')?.value || 'Nova categoria';
    const color = qs('#cat-color')?.value || '#14b8a6';
    const icon  = qs('#cat-icon')?.value || 'fa-tag';

    const badge = qs('#cat-preview');
    if (badge) {
      badge.style.setProperty('--_badge', color);
      badge.innerHTML = `
        <i class="fa-solid ${escapeHtml(icon)}" style="color:${escapeHtml(color)}"></i>
        <span class="t">${escapeHtml(name)}</span>
      `;
    }
    const chip = qs('#cat-color-chip');
    if (chip) chip.style.background = color;
  }

  function wireGoalMask() {
    const inp = qs('#cat-goal');
    if (!inp || inp.dataset.masked) return;
    inp.dataset.masked = '1';
    inp.addEventListener('blur', () => {
      const v = inp.value.trim();
      if (!v) { inp.value = ''; return; }
      const n = parseBRNumber(v);
      inp.value = (Number.isFinite(n) && n > 0) ? toBRL(n) : '';
    });
  }

  function setupCatFormUX() {
    const name  = qs('#cat-name');
    const color = qs('#cat-color');
    const icon  = qs('#cat-icon');
    if (!name || !color || !icon) return;
    if (setupCatFormUX._wired) return;
    setupCatFormUX._wired = true;

    ['input', 'change'].forEach(evt => {
      name.addEventListener(evt, updateCatPreview);
      color.addEventListener(evt, updateCatPreview);
      icon.addEventListener(evt, updateCatPreview);
    });

    updateCatPreview();
    wireGoalMask();
  }

  /* ------------------ CRUD ------------------ */
  async function saveCategoryFromForm() {
    const id    = qs('#cat-id')?.value || (uuid ? uuid() : crypto.randomUUID?.() || Math.random().toString(36).slice(2));
    const name  = (qs('#cat-name')?.value || '').trim();
    const color = qs('#cat-color')?.value || '#14b8a6';
    const icon  = (qs('#cat-icon')?.value || '').trim() || 'fa-tag';
    const goalRaw = qs('#cat-goal')?.value;
    const monthlyGoal = goalRaw ? parseBRNumber(goalRaw) : null;

    if (!name) throw new Error('Nome obrigatório');

    await addCategory({ id, name, color, icon, monthlyGoal });
    showToast?.('Categoria salva.');
    BUS.emit('cat:changed');
    resetCatForm();
  }

  async function removeCategory(id) {
    const ok = confirm('Excluir esta categoria? (não exclui lançamentos antigos)');
    if (!ok) return;
    await deleteCategory(id);
    showToast?.('Categoria excluída.');
    BUS.emit('cat:changed');
  }

  function fillFormForEdit(cat) {
    qs('#cat-id').value = cat.id;
    qs('#cat-name').value = cat.name;
    qs('#cat-color').value = cat.color || '#14b8a6';
    qs('#cat-icon').value = cat.icon || 'fa-tag';
    qs('#cat-goal').value = cat.monthlyGoal ?? '';
    updateCatPreview();
  }

  /* ------------------ Gasto no mês / Tabela ------------------ */
  async function spentByCategoryThisMonth() {
    const { y, m } = getCurrentYM();
    const txs = await getTxByMonth(y, m);
    const totals = new Map();
    for (const t of txs) {
      if (t.type !== 'expense') continue;
      totals.set(t.categoryId, (totals.get(t.categoryId) || 0) + (t.amount || 0));
    }
    return totals;
  }

  let _spentCache = null;

  async function renderCategoryTable() {
    const tbody = qs('#cat-table tbody'); if (!tbody) return;

    const [cats, spent] = await Promise.all([listCategories(), spentByCategoryThisMonth()]);
    _spentCache = spent;
    cats.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt-BR'));

    tbody.innerHTML = '';
    const frag = document.createDocumentFragment();

    for (const c of cats) {
      const used = spent.get(c.id) || 0;
      const tr = document.createElement('tr');
      tr.dataset.cname = c.name;
      tr.dataset.cid   = c.id;

      const tdName = document.createElement('td');
      tdName.innerHTML = `
        <span class="cat-name">
          <i class="fa-solid ${escapeHtml(c.icon || 'fa-tag')}" style="color:${escapeHtml(c.color || 'inherit')}"></i>
          ${escapeHtml(c.name)}
        </span>
      `;

      const tdGoal = document.createElement('td');
      tdGoal.className = 'cell-goal';
      tdGoal.textContent = c.monthlyGoal != null ? toBRL(c.monthlyGoal) : '—';

      const tdSpent = document.createElement('td');
      tdSpent.className = 'cell-spent';
      tdSpent.textContent = toBRL(used);

      const tdProg = document.createElement('td');
      tdProg.className = 'cell-prog';
      if (c.monthlyGoal && c.monthlyGoal > 0) {
        const ratio = Math.min(used / c.monthlyGoal, 1);
        const cls = ratio < 0.6 ? 'ok' : (ratio < 0.9 ? 'warn' : 'alert');
        tdProg.innerHTML = `
          <div class="progress ${cls}" title="${Math.round(ratio*100)}%">
            <span style="width:${(ratio*100).toFixed(1)}%"></span>
          </div>
        `;
      } else {
        tdProg.innerHTML = `<span class="muted">Sem meta</span>`;
      }

      const tdActions = document.createElement('td');
      tdActions.className = 'row-actions';
      tdActions.innerHTML = `
        <button class="btn" data-act="edit" data-id="${c.id}" title="Editar"><i class="fa-solid fa-pen"></i></button>
        <button class="btn" data-act="del" data-id="${c.id}" title="Excluir"><i class="fa-solid fa-trash"></i></button>
      `;

      tr.append(tdName, tdGoal, tdSpent, tdProg, tdActions);
      frag.appendChild(tr);
    }

    tbody.appendChild(frag);
  }

  /* ------------------ Metas: salário, sugestão e perfil ------------------ */
  async function suggestGoalsFromSalary() {
    const input = qs('#salary-input');
    const raw = parseBRNumber(input?.value);
    if (!Number.isFinite(raw) || raw <= 0) {
      showToast?.('Informe um salário válido.');
      input?.focus(); return;
    }
    const salary = raw;
    const reserve = salary * 0.10;
    const pool = salary - reserve;

    const cats = await listCategories();
    const byName = new Map(cats.map(c => [c.name, c]));
    const totalWeight = GOAL_PROFILE.reduce((s, [, w]) => s + w, 0);

    for (const [name, weight] of GOAL_PROFILE) {
      const c = byName.get(name);
      if (!c) continue;
      const goal = (pool * (weight / totalWeight));
      await updateCategory({ ...c, monthlyGoal: Math.round(goal * 100) / 100 });
    }

    showToast?.('Metas sugeridas aplicadas! (10% reservado p/ poupança)');
    BUS.emit('cat:changed');
  }

  async function loadSavedSalary() {
    const s = await getSetting('salary');
    if (s != null) qs('#salary-input').value = s;
  }

  async function saveSalary() {
    const v = parseBRNumber(qs('#salary-input')?.value);
    if (!Number.isFinite(v) || v <= 0) { showToast?.('Salário inválido.'); return; }
    await setSetting('salary', v);
    showToast?.('Salário salvo.');
  }

  async function renderGoalProfileUI() {
    const cont = qs('#cat-profile'); if (!cont) return;
    cont.innerHTML = '';

    const savedProfile = (await getSetting('goalProfile')) || {};
    GOAL_PROFILE.forEach(([name, defW]) => {
      const weight = savedProfile[name] ?? defW;
      const row = document.createElement('div');
      row.className = 'profile-row';
      row.innerHTML = `
        <label>${escapeHtml(name)}</label>
        <input type="range" min="0" max="50" step="1" value="${weight}" data-name="${escapeHtml(name)}">
        <span class="val">
          <span class="valp">${weight}%</span>
          <span class="valbr">—</span>
        </span>
      `;
      cont.appendChild(row);
    });

    // listeners dos sliders + debounce para preview
    let _previewTimer = null;
    cont.querySelectorAll('input[type=range]').forEach(sl => {
      sl.addEventListener('input', (e) => {
        const wrap = e.target.nextElementSibling;
        const valp = wrap?.querySelector('.valp');
        if (valp) valp.textContent = e.target.value + '%';

        clearTimeout(_previewTimer);
        _previewTimer = setTimeout(async () => {
          await previewGoalsFromSliders();
          await updateSliderMoneyLabels();
        }, 80);
      });
    });

    await updateSliderMoneyLabels();
  }

  function readLiveProfileFromUI() {
    const cont = qs('#cat-profile'); if (!cont) return null;
    const profile = {};
    cont.querySelectorAll('input[type=range]').forEach(sl => {
      profile[sl.dataset.name] = parseInt(sl.value, 10);
    });
    return profile;
  }

  function normalizeProfileTo90(profile) {
    const total = Object.values(profile).reduce((a, b) => a + b, 0);
    if (total <= 0) return null;
    const factor = 90 / total;
    const out = {};
    for (const k in profile) out[k] = Math.round(profile[k] * factor);
    return out;
  }

  function computeGoalsFromProfile(profile, salary) {
    const reserve = salary * 0.10;
    const pool = salary - reserve;
    const totalWeight = Object.values(profile).reduce((a, b) => a + b, 0);
    const goals = {};
    for (const [name, weight] of Object.entries(profile)) {
      goals[name] = Math.round((pool * (weight / totalWeight)) * 100) / 100;
    }
    return goals;
  }

  async function previewGoalsFromSliders() {
    const salary = await getSetting('salary');
    if (!salary) return;

    const base = readLiveProfileFromUI();
    if (!base) return;

    const normalized = normalizeProfileTo90(base);
    if (!normalized) return;

    const goals = computeGoalsFromProfile(normalized, salary);
    const tbody = qs('#cat-table tbody'); if (!tbody) return;

    const spent = _spentCache || new Map();

    tbody.querySelectorAll('tr').forEach(tr => {
      const name = tr.dataset.cname;
      const id   = tr.dataset.cid;
      const goal = goals[name];

      const cellGoal = tr.querySelector('.cell-goal');
      const cellProg = tr.querySelector('.cell-prog');

      if (goal !== undefined) {
        if (cellGoal) cellGoal.textContent = toBRL(goal);

        const used = spent.get(id) || 0;
        if (cellProg) {
          if (goal > 0) {
            const ratio = Math.min(used / goal, 1);
            const cls = ratio < 0.6 ? 'ok' : (ratio < 0.9 ? 'warn' : 'alert');
            cellProg.innerHTML = `
              <div class="progress ${cls}" title="${Math.round(ratio*100)}%">
                <span style="width:${(ratio*100).toFixed(1)}%"></span>
              </div>
            `;
          } else {
            cellProg.innerHTML = `<span class="muted">Sem meta</span>`;
          }
        }
      }
    });
  }

  async function updateSliderMoneyLabels() {
    const salary = await getSetting('salary');
    const cont = qs('#cat-profile'); if (!cont || !salary) return;

    const base = readLiveProfileFromUI();
    if (!base) return;
    const normalized = normalizeProfileTo90(base);
    if (!normalized) return;
    const goals = computeGoalsFromProfile(normalized, salary);

    cont.querySelectorAll('.profile-row').forEach(row => {
      const name = row.querySelector('input[type=range]')?.dataset.name;
      const span = row.querySelector('.valbr');
      if (!name || !span) return;
      const brl = goals[name] != null ? toBRL(goals[name]) : '—';
      span.textContent = brl;
    });
  }

  async function saveGoalProfile() {
    const cont = qs('#cat-profile'); if (!cont) return;

    const profile = {};
    cont.querySelectorAll('input[type=range]').forEach(sl => {
      profile[sl.dataset.name] = parseInt(sl.value, 10);
    });

    const total = Object.values(profile).reduce((a, b) => a + b, 0);
    if (total <= 0) { showToast?.('Perfil inválido.'); return; }

    // normaliza para somar 90%
    const factor = 90 / total;
    for (const k in profile) profile[k] = Math.round(profile[k] * factor);

    await setSetting('goalProfile', profile);
    showToast?.('Perfil salvo!');
    await applyGoalProfile(profile);
  }

  async function applyGoalProfile(profile) {
    const salary = await getSetting('salary');
    if (!salary) { showToast?.('Defina o salário para aplicar o perfil.'); return; }

    const reserve = salary * 0.10;
    const pool = salary - reserve;

    const cats = await listCategories();
    const byName = new Map(cats.map(c => [c.name, c]));
    const totalWeight = Object.values(profile).reduce((a, b) => a + b, 0);

    for (const [name, weight] of Object.entries(profile)) {
      const c = byName.get(name);
      if (!c) continue;
      const goal = (pool * (weight / totalWeight));
      await updateCategory({ ...c, monthlyGoal: Math.round(goal * 100) / 100 });
    }
    BUS.emit('cat:changed');
  }

  /* ------------------ Hidratação de selects ------------------ */
  async function _getAllCategories() {
    if (typeof window.listCategories === 'function') return await window.listCategories();
    if (window.DB?.getAll) return await window.DB.getAll('categories');
    // Fallback direto
    const db = await new Promise((resolve, reject) => {
      const req = indexedDB.open('budgetwave_db', 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
    });
    return await new Promise((resolve, reject) => {
      const tx = db.transaction('categories', 'readonly');
      const store = tx.objectStore('categories');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function hydrateCategorySelects() {
    // inclui sempre os selects críticos mesmo sem data-cat-select
    const base = Array.from(document.querySelectorAll('select[data-cat-select]'));
    const extras = [
      document.getElementById('tx-category'),
      document.getElementById('txm-category'),
      document.getElementById('rule-category'),
      document.getElementById('tx-filter-category'),
    ].filter(Boolean);

    // de-dup
    const seen = new Set();
    const selects = [...base, ...extras].filter((el) => {
      if (!el) return false;
      if (seen.has(el)) return false;
      seen.add(el);
      return true;
    });
    if (!selects.length) return;

    const cats = await _getAllCategories();
    cats.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt-BR'));

    for (const sel of selects) {
      // garante que passe a fazer parte do ecossistema
      if (!sel.hasAttribute('data-cat-select')) sel.setAttribute('data-cat-select', '');

      const prev = sel.value;
      const isFilter = sel.id === 'tx-filter-category';
      const wantsPlaceholder = sel.hasAttribute('data-placeholder');

      let html = '';
      if (isFilter) {
        html += `<option value="all">Todas</option>`;
      } else if (wantsPlaceholder) {
        // placeholder visível (sem hidden) para evitar menu “vazio”
        html += `<option value="" disabled selected>Selecione…</option>`;
      }
      for (const c of cats) html += `<option value="${c.id}">${escapeHtml(c.name || '')}</option>`;
      sel.innerHTML = html;

      if (prev && (prev === 'all' || cats.some(c => c.id === prev))) {
        sel.value = prev;
      } else if (isFilter) {
        sel.value = 'all';
      } else if (wantsPlaceholder) {
        sel.selectedIndex = 0; // mantém placeholder
      }
      sel.dispatchEvent(new Event('change', { bubbles: true }));
    }

    window.__debugCats && window.__debugCats();
  }

  // Expor p/ outros módulos
  window.hydrateCategorySelects = hydrateCategorySelects;

  // Hidratações defensivas pós-load (pós-seed/primeiros renders)
  window.addEventListener('load', () => {
    hydrateCategorySelects();
    setTimeout(hydrateCategorySelects, 150);
  });

  /* ------------------ Icon Combobox (sugestões ricas) ------------------ */
  const ICON_SUGGESTIONS = [
    { value: 'fa-cart-shopping', label: 'Mercado / Compras',      desc: 'Supermercado, farmácia, shopping' },
    { value: 'fa-burger',        label: 'Alimentação / Lanches',   desc: 'Lanches, delivery, fast-food'     },
    { value: 'fa-bus',           label: 'Transporte público',      desc: 'Ônibus, metrô, trem'              },
    { value: 'fa-car',           label: 'Transporte (Carro/Uber)', desc: 'Combustível, estacionamento, Uber'},
    { value: 'fa-house',         label: 'Moradia / Casa',          desc: 'Aluguel, condomínio, reformas'    },
    { value: 'fa-graduation-cap',label: 'Educação / Estudos',      desc: 'Cursos, livros, mensalidades'     },
    { value: 'fa-heart-pulse',   label: 'Saúde',                   desc: 'Consultas, exames, farmácia'      },
    { value: 'fa-coins',         label: 'Renda / Dinheiro',        desc: 'Salário, rendas extras'           },
    { value: 'fa-gamepad',       label: 'Lazer / Jogos',           desc: 'Jogos, diversão, hobbies'         },
    { value: 'fa-utensils',      label: 'Restaurantes',            desc: 'Almoço/jantar fora'               },
  ];

  function makeIconSuggest(anchorInput) {
    const wrap = document.createElement('div');
    wrap.className = 'icon-suggest hidden';
    wrap.setAttribute('role', 'listbox');
    anchorInput.parentElement.style.position = 'relative';
    anchorInput.parentElement.appendChild(wrap);

    let currentIndex = -1;
    let filtered = ICON_SUGGESTIONS.slice();

    function render() {
      wrap.innerHTML = '';
      filtered.forEach((opt, idx) => {
        const item = document.createElement('div');
        item.className = 'icon-suggest__item';
        item.tabIndex = -1;
        item.setAttribute('role', 'option');
        item.setAttribute('data-value', opt.value);
        item.setAttribute('aria-selected', String(idx === currentIndex));

        item.innerHTML = `
          <i class="fa-solid ${opt.value}"></i>
          <div>
            <div class="icon-suggest__title">${escapeHtml(opt.value)} — ${escapeHtml(opt.label)}</div>
            <div class="icon-suggest__desc">${escapeHtml(opt.desc)}</div>
          </div>
        `;
        item.addEventListener('mousedown', (e) => {
          e.preventDefault();
          anchorInput.value = opt.value;
          updateCatPreview();
          close();
        });
        wrap.appendChild(item);
      });
    }

    function open()  { wrap.classList.remove('hidden'); }
    function close() { wrap.classList.add('hidden'); currentIndex = -1; }
    function move(delta) {
      if (!filtered.length) return;
      currentIndex = (currentIndex + delta + filtered.length) % filtered.length;
      [...wrap.children].forEach((el, i) => el.setAttribute('aria-selected', String(i === currentIndex)));
      wrap.children[currentIndex]?.scrollIntoView({ block: 'nearest' });
    }
    function commit() {
      if (currentIndex < 0 || !filtered[currentIndex]) return;
      anchorInput.value = filtered[currentIndex].value;
      updateCatPreview();
      close();
    }

    function filter(q) {
      const s = normalizeText((q || '').trim());
      if (!s) filtered = ICON_SUGGESTIONS.slice();
      else {
        filtered = ICON_SUGGESTIONS.filter(o =>
          normalizeText(o.value).includes(s) ||
          normalizeText(o.label).includes(s) ||
          normalizeText(o.desc).includes(s)
        );
      }
      currentIndex = -1;
      render();
    }

    anchorInput.addEventListener('focus', () => { filter(anchorInput.value); open(); });
    anchorInput.addEventListener('input', () => { filter(anchorInput.value); open(); });
    anchorInput.addEventListener('blur',  () => { setTimeout(close, 100); });
    anchorInput.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); open(); move(+1); }
      if (e.key === 'ArrowUp')   { e.preventDefault(); open(); move(-1); }
      if (e.key === 'Enter')     { e.preventDefault(); commit(); }
      if (e.key === 'Escape')    { e.preventDefault(); close(); }
    });

    render();
  }

  function setupIconCombobox() {
    const input = qs('#cat-icon');
    if (!input || input.dataset.suggest) return;
    input.dataset.suggest = '1';
    makeIconSuggest(input);
  }

  /* ------------------ UI Wiring ------------------ */
  function setupCategoriesUI() {
    if (setupCategoriesUI._wired) return;
    setupCategoriesUI._wired = true;

    qs('#cat-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await saveCategoryFromForm();
        await renderCategoryTable();
        await previewGoalsFromSliders();
        await updateSliderMoneyLabels();
      } catch (err) {
        console.error(err);
        showToast?.(err.message || 'Erro ao salvar categoria');
      }
    });

    qs('#cat-reset')?.addEventListener('click', resetCatForm);

    qs('#btn-suggest')?.addEventListener('click', async (e) => {
      const btn = e.currentTarget; btn.disabled = true;
      try {
        await suggestGoalsFromSalary();
        await renderCategoryTable();
        await previewGoalsFromSliders();
        await updateSliderMoneyLabels();
      } finally {
        btn.disabled = false;
      }
    });

    qs('#btn-save-salary')?.addEventListener('click', async () => {
      await saveSalary();
      await previewGoalsFromSliders();
      await updateSliderMoneyLabels();
    });

    qs('#btn-save-profile')?.addEventListener('click', saveGoalProfile);

    qs('#cat-table')?.addEventListener('click', async (ev) => {
      const btn = ev.target.closest('button[data-act]'); if (!btn) return;
      const id = btn.getAttribute('data-id');
      const act = btn.getAttribute('data-act');

      const cats = await listCategories();
      const cat = cats.find(c => c.id === id);
      if (!cat) return;

      if (act === 'edit') { fillFormForEdit(cat); }
      if (act === 'del') {
        await removeCategory(id);
        await renderCategoryTable();
        await previewGoalsFromSliders();
        await updateSliderMoneyLabels();
      }
    });
  }

  /* ------------------ Ciclo de vida ------------------ */
  BUS.on('db:ready', async () => {
    setupCategoriesUI();
    setupCatFormUX();
    setupIconCombobox();
    await loadSavedSalary();
    resetCatForm();
    await renderCategoryTable();
    await renderGoalProfileUI();
    await previewGoalsFromSliders();
    await updateSliderMoneyLabels();
    // hidratação dos selects (inclui #tx-category, #rule-category etc.)
    hydrateCategorySelects();
    setTimeout(hydrateCategorySelects, 80); // fallback pós-seed
  });

  BUS.on('tx:changed', async () => {
    await renderCategoryTable();
    await previewGoalsFromSliders();
    await updateSliderMoneyLabels();
  });

  BUS.on('cat:changed', async () => {
    await renderCategoryTable();
    await previewGoalsFromSliders();
    await updateSliderMoneyLabels();
    hydrateCategorySelects();
  });

  BUS.on('ui:tab', (tabId) => {
    if (tabId === 'lancamentos' || tabId === 'config' || tabId === 'relatorios') {
      hydrateCategorySelects();
      if (tabId === 'lancamentos') setTimeout(hydrateCategorySelects, 120);
    }
  });
})();
// path: budgetwave/scripts/categories.js
// PATCH 1 — util interno para garantir o combo sempre populado (debounced)
function __ensureTxCategoryPopulated() {
  const sel = document.getElementById('tx-category');
  if (!sel) return;
  // se tem só placeholder (<=1 opção), reidrata
  if (sel.options.length <= 1) {
    hydrateCategorySelects();
  }
}

// Debounce simples para o observer
let __txHydrateTimer = null;
function __requestTxHydration() {
  clearTimeout(__txHydrateTimer);
  __txHydrateTimer = setTimeout(__ensureTxCategoryPopulated, 80);
}
// path: budgetwave/scripts/categories.js
// PATCH 2 — começar a observar mudanças no DOM (re-render do formulário)
window.addEventListener('DOMContentLoaded', () => {
  try {
    const mo = new MutationObserver((mutations) => {
      // só reage se tocar em selects ou na área de lançamentos
      for (const m of mutations) {
        if (m.type === 'childList') {
          if (
            (m.addedNodes && m.addedNodes.length) ||
            (m.target && (m.target.id === 'tx-form' || m.target.id === 'tx-category'))
          ) {
            __requestTxHydration();
          }
        }
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  } catch (e) {
    // se MutationObserver falhar por algum motivo, tentamos por timeout
    setInterval(__ensureTxCategoryPopulated, 500);
  }
});

// reforço ao trocar para a aba de Lançamentos
BUS.on('ui:tab', (tabId) => {
  if (tabId === 'lancamentos') {
    hydrateCategorySelects();
    setTimeout(hydrateCategorySelects, 150);
    setTimeout(__ensureTxCategoryPopulated, 350); // re-render tardio
  }
});
