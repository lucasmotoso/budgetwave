/* Charts do Dashboard (Chart.js)
   - Pie (despesas por categoria do mês corrente)
   - Line (saldo acumulado diário do mês corrente)
   - Ajuste automático ao tema; re-render quando dados/tema mudarem
*/
(function(){
  let pieChart = null;
  let lineChart = null;

  function getYM(){ const d=new Date(); return { y:d.getFullYear(), m:d.getMonth()+1 } }
  function daysInMonth(y,m){ return new Date(y, m, 0).getDate() }
  function cssVar(name){ return getComputedStyle(document.documentElement).getPropertyValue(name).trim() }
  function brl(v){ return new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(v||0) }

  function chartColors(){
    return {
      text: cssVar('--text') || '#e5e7eb',
      grid: cssVar('--elev-2') || 'rgba(255,255,255,.08)',
      border: cssVar('--elev-3') || 'rgba(255,255,255,.12)',
      primary: cssVar('--primary') || '#22d3ee',
      accent: cssVar('--accent') || '#a78bfa',
      ok: cssVar('--ok') || '#22c55e',
      warn: cssVar('--warn') || '#f59e0b',
      alert: cssVar('--alert') || '#ef4444',
      card: cssVar('--card') || '#0b1220',
    };
  }

  // ----- Pie: despesas por categoria -----
  async function renderPie(){
    const {y,m} = getYM();
    const cats = await listCategories();
    const txs = await getTxByMonth(y,m);

    const totals = new Map();
    for(const t of txs){
      if(t.type !== 'expense') continue;
      totals.set(t.categoryId,(totals.get(t.categoryId)||0)+(t.amount||0));
    }
    const items = [];
    for(const c of cats){
      const v = totals.get(c.id)||0;
      if(v>0) items.push({label:c.name, value:v, color:c.color||'#888'});
    }

    const wrapEmpty = document.getElementById('ch-pie-empty');
    const ctx = document.getElementById('ch-pie')?.getContext('2d');
    if(!ctx) return;
    if(pieChart){ pieChart.destroy(); pieChart=null; }

    if(items.length===0){
      if(wrapEmpty) wrapEmpty.hidden=false;
      return;
    }else if(wrapEmpty){ wrapEmpty.hidden=true; }

    const colors = chartColors();
    pieChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: items.map(i=>i.label),
        datasets: [{
          data: items.map(i=>i.value),
          backgroundColor: items.map(i=>i.color),
          borderColor: colors.card,
          borderWidth: 2,
          hoverOffset: 6
        }]
      },
      options: {
        plugins: {
          legend: { labels: { color: colors.text } },
          tooltip: {
            callbacks: {
              label(ctx){
                const val = ctx.raw || 0;
                const lab = ctx.label || '';
                const total = ctx.dataset.data.reduce((a,b)=>a+b,0) || 1;
                const pct = ((val/total)*100).toFixed(1).replace('.',',');
                return `${lab}: ${brl(val)} (${pct}%)`;
              }
            }
          }
        },
        cutout: '60%'
      }
    });
  }

  // ----- Line: saldo acumulado diário -----
  async function renderLine(){
    const {y,m} = getYM();
    const txs = await getTxByMonth(y,m);

    const wrapEmpty = document.getElementById('ch-line-empty');
    const ctx = document.getElementById('ch-line')?.getContext('2d');
    if(!ctx) return;
    if(lineChart){ lineChart.destroy(); lineChart=null; }

    if(txs.length===0){
      if(wrapEmpty) wrapEmpty.hidden=false;
      return;
    }else if(wrapEmpty){ wrapEmpty.hidden=true; }

    const colors = chartColors();
    const last = daysInMonth(y,m);
    const labels = Array.from({length:last},(_,i)=> String(i+1).padStart(2,'0'));

    const daily = new Array(last).fill(0);
    for(const t of txs){
      const d = Number(String(t.date||'').split('-')[2]) || 1;
      const idx = Math.max(1,Math.min(last,d)) - 1;
      const delta = t.type==='income' ? (t.amount||0) : -(t.amount||0);
      daily[idx] += delta;
    }
    const acc = [];
    daily.reduce((s,v,i)=> acc[i]=s+v, 0);

    lineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Saldo acumulado',
          data: acc,
          tension: .25,
          fill: true,
          borderWidth: 2,
          borderColor: colors.primary,
          backgroundColor: (ctx)=> {
            const {chart} = ctx;
            const g = chart.ctx.createLinearGradient(0,0,0,chart.height);
            g.addColorStop(0, colors.primary + '22');
            g.addColorStop(1, colors.card + '00');
            return g;
          },
          pointRadius: 0,
          pointHoverRadius: 3
        }]
      },
      options: {
        plugins: {
          legend: { labels: { color: colors.text } },
          tooltip: { callbacks: { label(c){ return ` ${brl(c.raw)}`; } } }
        },
        scales: {
          x: { ticks: { color: colors.text }, grid: { color: colors.grid } },
          y: { ticks: { color: colors.text, callback:(v)=>brl(v) }, grid: { color: colors.grid } }
        }
      }
    });
  }

  function updateThemeForCharts(){ renderPie(); renderLine(); }
  async function renderAll(){ await renderPie(); await renderLine(); }

  eventBus.on('db:ready', renderAll);
  eventBus.on('tx:changed', renderAll);
  eventBus.on('cat:changed', renderPie);
  eventBus.on('settings:changed', updateThemeForCharts);

  if(window.dbRef){ renderAll(); }
})();
// path: budgetwave/scripts/reports.js
/* BudgetWave — Relatórios
   Responsável por: UI da aba, filtros de período, gráficos (Chart.js) e exportações.
   Depende de: Chart.js (CDN), state.js (eventBus), db.js (IndexedDB), utils.js (helpers),
               categories.js (listCategories), transactions store.
   Não altera IDs existentes. Seguro para plug-and-play.
*/

(() => {
  const BUS = window.eventBus; // de state.js
  const CACHE = {
    monthAgg: new Map(), // chave: 'YYYY-MM' -> { expensesByCat, incomeTotal, expenseTotal }
  };
  const CHARTS = {
    pie: null,
    bars: null,
  };

  // Util: obter estilo atual (tema) a partir de CSS variables
  function themeVars() {
    const s = getComputedStyle(document.documentElement);
    const text = s.getPropertyValue('--text-color')?.trim() || '#ddd';
    const grid = s.getPropertyValue('--muted-3')?.trim() || 'rgba(200,200,200,0.15)';
    const card = s.getPropertyValue('--card-bg')?.trim() || '#121212';
    const bg = s.getPropertyValue('--app-bg')?.trim() || '#0b0b0b';
    return { text, grid, card, bg };
  }

  // Util: datas
  function startEndOfMonth(ym) {
    const [y, m] = ym.split('-').map(Number);
    const start = new Date(y, m - 1, 1);
    const end = new Date(y, m, 0); // último dia do mês
    return { start, end };
  }
  function ymKey(d) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }
  function monthSequence(backMonths = 6, includeCurrent = true) {
    const out = [];
    const base = new Date();
    let curYm = ymKey(base);
    if (!includeCurrent) {
      // volta um mês antes de começar
      base.setMonth(base.getMonth() - 1);
      curYm = ymKey(base);
    }
    for (let i = 0; i < backMonths; i++) {
      const dt = new Date(base.getFullYear(), base.getMonth() - i, 1);
      out.push(ymKey(dt));
    }
    return out.reverse();
  }

  // Fallback robusto para obter todas transações:
  // 1) tenta função util se existir (listTransactions / DB.getAll)
  // 2) abre IndexedDB diretamente (não quebra se API interna variar)
  async function getAllTransactions() {
    if (typeof window.listTransactions === 'function') {
      return await window.listTransactions();
    }
    if (window.DB && typeof window.DB.getAll === 'function') {
      return await window.DB.getAll('transactions');
    }
    // indexedDB direto:
    const db = await new Promise((resolve, reject) => {
      const req = indexedDB.open('budgetwave_db', 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
    });
    return await new Promise((resolve, reject) => {
      const tx = db.transaction('transactions', 'readonly');
      const store = tx.objectStore('transactions');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAllCategories() {
    if (typeof window.listCategories === 'function') {
      return await window.listCategories();
    }
    if (window.DB && typeof window.DB.getAll === 'function') {
      return await window.DB.getAll('categories');
    }
    // indexedDB direto:
    const db = await new Promise((resolve, reject) => {
      const req = indexedDB.open('budgetwave_db', 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
    });
    return await new Promise((resolve, reject) => {
      const tx = db.transaction('categories', 'readonly');
      const store = tx.objectStore('categories');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  // Helpers de formatação (usa utils.js se disponível; senão fallback simples)
  function fmtBRL(v) {
    if (window.Utils?.formatCurrencyBR) return window.Utils.formatCurrencyBR(v);
    try {
      return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);
    } catch {
      return `R$ ${Number(v).toFixed(2)}`;
    }
  }
  function fmtDateBR(iso) {
    if (!iso) return '';
    const [y, m, d] = iso.split('-').map(Number);
    return `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y}`;
  }

  // Agregação de um mês (com cache)
  async function aggregateMonth(ym) {
    if (CACHE.monthAgg.has(ym)) return CACHE.monthAgg.get(ym);

    const cats = await getAllCategories();
    const catById = new Map(cats.map(c => [c.id, c]));

    const { start, end } = startEndOfMonth(ym);
    const txs = await getAllTransactions();
    const inMonth = txs.filter(t => {
      if (!t?.date) return false;
      const dt = new Date(t.date);
      return dt >= start && dt <= end;
    });

    const expensesByCat = new Map(); // catId -> total
    let incomeTotal = 0;
    let expenseTotal = 0;

    for (const t of inMonth) {
      if (t.type === 'income') {
        incomeTotal += Math.abs(Number(t.amount) || 0);
      } else if (t.type === 'expense') {
        const val = Math.abs(Number(t.amount) || 0);
        expenseTotal += val;
        const k = t.categoryId || '__uncategorized__';
        expensesByCat.set(k, (expensesByCat.get(k) || 0) + val);
      }
    }

    const result = { expensesByCat, incomeTotal, expenseTotal, catById };
    CACHE.monthAgg.set(ym, result);
    return result;
  }

  // Render: Pizza por categoria (despesas) do mês
  async function renderPieByCategory(periodYM) {
    const pieEl = document.getElementById('reports-pie');
    if (!pieEl) return;
    const { text } = themeVars();
    const { expensesByCat, catById } = await aggregateMonth(periodYM);

    const labels = [];
    const data = [];
    const colors = [];

    // Paleta fallback suave
    const fallback = [
      '#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6',
      '#ec4899', '#22c55e', '#06b6d4', '#eab308', '#f97316'
    ];

    let fIdx = 0;
    for (const [catId, total] of expensesByCat.entries()) {
      const cat = catById.get(catId);
      labels.push(cat?.name || 'Sem categoria');
      data.push(Number(total.toFixed(2)));
      colors.push(cat?.color || fallback[fIdx++ % fallback.length]);
    }

    // Destroy anterior
    if (CHARTS.pie) {
      CHARTS.pie.destroy();
      CHARTS.pie = null;
    }

    CHARTS.pie = new Chart(pieEl.getContext('2d'), {
      type: 'pie',
      data: {
        labels,
        datasets: [{
          data,
          borderWidth: 1,
        }],
      },
      options: {
        plugins: {
          legend: { labels: { color: text } },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const v = ctx.parsed || 0;
                const pct = data.length ? (v / data.reduce((a, b) => a + b, 0)) * 100 : 0;
                return `${ctx.label}: ${fmtBRL(v)} (${pct.toFixed(1)}%)`;
              }
            }
          }
        }
      }
    });

    // aplicar cores após instanciar (garante consistência no tema)
    if (CHARTS.pie?.data?.datasets?.[0]) {
      CHARTS.pie.data.datasets[0].backgroundColor = colors;
      CHARTS.pie.update();
    }
  }

  // Render: Barras Receitas x Despesas (últimos N meses)
  async function renderBarsIncomeVsExpense({ months = 6 } = {}) {
    const barsEl = document.getElementById('reports-bars');
    if (!barsEl) return;
    const { text, grid } = themeVars();

    const monthsList = monthSequence(months, true);
    const labels = [];
    const income = [];
    const expense = [];

    for (const ym of monthsList) {
      const { incomeTotal, expenseTotal } = await aggregateMonth(ym);
      const [y, m] = ym.split('-').map(Number);
      labels.push(`${String(m).padStart(2, '0')}/${String(y).slice(-2)}`);
      income.push(Number(incomeTotal.toFixed(2)));
      expense.push(Number(expenseTotal.toFixed(2)));
    }

    if (CHARTS.bars) {
      CHARTS.bars.destroy();
      CHARTS.bars = null;
    }

    CHARTS.bars = new Chart(barsEl.getContext('2d'), {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Receitas', data: income },
          { label: 'Despesas', data: expense },
        ],
      },
      options: {
        responsive: true,
        scales: {
          x: {
            ticks: { color: text },
            grid: { color: grid },
          },
          y: {
            ticks: {
              color: text,
              callback: (v) => fmtBRL(v),
            },
            grid: { color: grid },
          }
        },
        plugins: {
          legend: { labels: { color: text } },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${fmtBRL(ctx.parsed.y || 0)}`
            }
          }
        }
      }
    });
  }

  // Atualiza cores de gráficos conforme o tema muda
  function updateThemeForReports() {
    const { text, grid } = themeVars();
    [CHARTS.pie, CHARTS.bars].forEach(ch => {
      if (!ch) return;
      if (ch.options?.plugins?.legend?.labels) {
        ch.options.plugins.legend.labels.color = text;
      }
      if (ch.options?.scales) {
        for (const k of Object.keys(ch.options.scales)) {
          const sc = ch.options.scales[k];
          if (sc.ticks) sc.ticks.color = text;
          if (sc.grid) sc.grid.color = grid;
        }
      }
      ch.update();
    });
  }

  // Exportações do período selecionado (CSV / JSON)
  async function exportCSV(periodYM) {
    const { start, end } = startEndOfMonth(periodYM);
    const txs = (await getAllTransactions()).filter(t => {
      if (!t?.date) return false;
      const dt = new Date(t.date);
      return dt >= start && dt <= end;
    });

    // Cabeçalho alinhado com import/export existente
    const header = ['Data', 'Descrição', 'Categoria', 'Tipo', 'Valor'];
    const cats = await getAllCategories();
    const catById = new Map(cats.map(c => [c.id, c]));

    const rows = txs.map(t => {
      const catName = catById.get(t.categoryId)?.name || '';
      const valor = Number(t.amount) || 0;
      return [
        fmtDateBR(t.date),
        (t.description || '').replace(/\s+/g, ' ').trim(),
        catName,
        t.type || '',
        valor.toFixed(2).replace('.', ','), // número BR
      ];
    });

    const csv = [header, ...rows].map(r =>
      r.map(cell => {
        const s = String(cell);
        return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
      }).join(';')
    ).join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `budgetwave_${periodYM}_relatorio.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    BUS.emit('ui:toast', { type: 'success', message: 'CSV exportado com sucesso.' });
  }

  async function exportJSON(periodYM) {
    const { start, end } = startEndOfMonth(periodYM);
    const txs = (await getAllTransactions()).filter(t => {
      if (!t?.date) return false;
      const dt = new Date(t.date);
      return dt >= start && dt <= end;
    });
    const payload = {
      period: periodYM,
      exportedAt: new Date().toISOString(),
      transactions: txs,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `budgetwave_${periodYM}_relatorio.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    BUS.emit('ui:toast', { type: 'success', message: 'JSON exportado com sucesso.' });
  }

  // UI handlers
  function bindUI() {
    const selPeriod = document.getElementById('reports-period');
    const selRange = document.getElementById('reports-range');
    const btnCSV = document.getElementById('reports-export-csv');
    const btnJSON = document.getElementById('reports-export-json');

    if (selPeriod) {
      // hidrata com mês atual + últimos 11 meses
      const months = monthSequence(12, true);
      selPeriod.innerHTML = '';
      for (const ym of months.reverse()) {
        // adiciona os mais antigos por último; depois invertido para atual no topo
      }
      const list = monthSequence(12, true); // atual e 11 anteriores
      selPeriod.innerHTML = list.map(ym => {
        const [y, m] = ym.split('-').map(Number);
        return `<option value="${ym}">${String(m).padStart(2,'0')}/${y}</option>`;
      }).join('');
      // seleciona mês atual
      selPeriod.value = ymKey(new Date());

      selPeriod.addEventListener('change', async () => {
        await renderPieByCategory(selPeriod.value);
      });
    }

    if (selRange) {
      selRange.addEventListener('change', async () => {
        const months = Number(selRange.value) || 6;
        await renderBarsIncomeVsExpense({ months });
      });
    }

    if (btnCSV) btnCSV.addEventListener('click', () => exportCSV(selPeriod.value || ymKey(new Date())));
    if (btnJSON) btnJSON.addEventListener('click', () => exportJSON(selPeriod.value || ymKey(new Date())));
  }

  async function renderReportsUI() {
    bindUI();
    const period = (document.getElementById('reports-period')?.value) || ymKey(new Date());
    const months = Number(document.getElementById('reports-range')?.value) || 6;
    await Promise.all([
      renderPieByCategory(period),
      renderBarsIncomeVsExpense({ months }),
    ]);
  }

  // Reagir a mudanças (tema e dados)
  function wireBus() {
    BUS.on('settings:changed', () => {
      // tema pode ter mudado; atualiza cores
      updateThemeForReports();
    });
    BUS.on('tx:changed', async () => {
      // limpa cache do mês atual e re-render se estiver na aba
      CACHE.monthAgg.clear();
      if (isReportsTabActive()) await renderReportsUI();
    });
    BUS.on('cat:changed', async () => {
      CACHE.monthAgg.clear();
      if (isReportsTabActive()) await renderReportsUI();
    });
    BUS.on('ui:tab', async (tabId) => {
      if (tabId === 'reports') {
        await renderReportsUI();
      }
    });
  }

  function isReportsTabActive() {
    // considera que a UI emite 'ui:tab' com id "reports"
    const tab = document.querySelector('[data-tab="reports"]');
    return !!(tab && tab.classList.contains('is-active'));
  }

  // Exposição pública
  window.Reports = {
    renderReportsUI,
    renderPieByCategory,
    renderBarsIncomeVsExpense,
    updateThemeForReports,
    exportCSV,
    exportJSON,
  };

  // Boot
  document.addEventListener('DOMContentLoaded', () => {
    wireBus();
    // Se a aba "Relatórios" é a atual na carga (raro), renderiza
    if (isReportsTabActive()) {
      renderReportsUI();
    }
  });
})();
