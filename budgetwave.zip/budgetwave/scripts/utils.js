// path: budgetwave/scripts/utils.js
// Utilidades: seleção DOM, toasts, formatação BRL, datas, UUID, normalização e downloads.
// Não depende de outros módulos. Expõe window.Utils para consumo pelos demais scripts.

(() => {
  // -----------------------------
  // DOM helpers
  // -----------------------------
  const qs = (sel, el = document) => el.querySelector(sel);
  const qsa = (sel, el = document) => [...el.querySelectorAll(sel)];

  // -----------------------------
  // Toasts (acessível + fila)
  // -----------------------------
  const TOAST_SHOW_MS = 1800;
  const TOAST_TRANSITION_MS = 160;
  let toastQueue = [];
  let toastBusy = false;

  function getToastBox() {
    // procura sempre que precisar (index pode trocar)
    return document.getElementById('toast');
  }

  function _renderToast(msg) {
    const box = getToastBox();
    if (!box) return; // silencioso se layout não tiver o #toast
    box.textContent = msg;
    box.style.transition = `opacity ${TOAST_TRANSITION_MS}ms ease, transform ${TOAST_TRANSITION_MS}ms ease`;
    box.style.opacity = '1';
    box.style.transform = 'translateY(0)';
    // acessibilidade
    box.setAttribute('role', 'status');
    box.setAttribute('aria-live', 'polite');
  }

  function _hideToast() {
    const box = getToastBox();
    if (!box) return;
    box.style.opacity = '0';
    box.style.transform = 'translateY(10px)';
  }

  function showToast(message) {
    const msg = String(message ?? '').trim();
    if (!msg) return;
    toastQueue.push(msg);
    if (toastBusy) return;
    toastBusy = true;

    const next = () => {
      const m = toastQueue.shift();
      if (!m) {
        toastBusy = false;
        return;
      }
      _renderToast(m);
      setTimeout(() => {
        _hideToast();
        setTimeout(next, TOAST_TRANSITION_MS);
      }, TOAST_SHOW_MS);
    };
    next();
  }

  // -----------------------------
  // Moeda BRL
  // -----------------------------
  const _fmtBRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

  function toBRL(n) {
    const x = typeof n === 'number' ? n : parseBRNumber(n);
    return _fmtBRL.format(Number.isFinite(x) ? x : 0);
  }

  // Aceita: "1.234,56", "1234,56", "1 234,56", "R$ 1.234,56", "-1.234,56", "1234.56"
  function parseBRNumber(input) {
    if (input == null || input === '') return 0;
    if (typeof input === 'number') return input;
    let s = String(input)
      .replace(/\s/g, '')
      .replace(/R\$\s?/i, '')
      .replace(/\./g, '')
      .replace(',', '.')
      .replace(/[^\d.-]/g, ''); // remove tudo exceto dígitos, ponto e sinal
    // Tratar múltiplos sinais/ pontos estranhos
    const sign = (s.match(/-/g) || []).length % 2 ? -1 : 1;
    s = s.replace(/-/g, '');
    const v = Number(s);
    return Number.isFinite(v) ? sign * v : 0;
  }

  // -----------------------------
  // Datas
  // -----------------------------
  // YYYY-MM-DD de hoje
  function ymdToday() {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}-${m}-${day}`;
  }

  // YYYY-MM ou YYYY-MM-DD -> {year, month}
  function monthParts(dateStr) {
    if (!dateStr) return { year: NaN, month: NaN };
    const [y, m] = String(dateStr).split('-');
    return { year: Number(y), month: Number(m) };
  }

  // YYYY-MM-DD -> DD/MM/YYYY
  function formatDMY(iso) {
    if (!iso) return '';
    const [y, m, d] = String(iso).split('-');
    return `${d}/${m}/${y}`;
  }

  // YYYY-MM key do mês de uma Date
  function ymKey(date) {
    const d = date instanceof Date ? date : new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  // Limites do mês: retorna { start: Date, end: Date }
  function monthBounds(ym) {
    const [y, m] = String(ym).split('-').map(Number);
    const start = new Date(y, m - 1, 1);
    const end = new Date(y, m, 0);
    return { start, end };
  }

  // Sequência de meses (YYYY-MM) do mais antigo para o mais novo
  function monthSequence(count = 6, includeCurrent = true) {
    const base = new Date();
    if (!includeCurrent) base.setMonth(base.getMonth() - 1);
    const out = [];
    for (let i = count - 1; i >= 0; i--) {
      const d = new Date(base.getFullYear(), base.getMonth() - i, 1);
      out.push(ymKey(d));
    }
    return out;
  }

  // -----------------------------
  // UUID v4 (suficiente para app local)
  // -----------------------------
  function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  // -----------------------------
  // Normalização de texto (busca/regras)
  // -----------------------------
  function normalizeText(s) {
    return (s || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // -----------------------------
  // Downloads (CSV/JSON/qualquer)
  // -----------------------------
  function download(filename, text, mime = 'application/octet-stream') {
    const blob = new Blob([text], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function downloadJSON(filename, obj) {
    download(filename, JSON.stringify(obj, null, 2), 'application/json');
  }

  function downloadCSV(filename, csvString) {
    download(filename, csvString, 'text/csv');
  }

  // -----------------------------
  // Exposição pública
  // -----------------------------
  window.Utils = Object.freeze({
    // DOM
    qs, qsa,
    // toasts
    showToast,
    // moeda
    toBRL, parseBRNumber,
    // datas
    ymdToday, monthParts, formatDMY, ymKey, monthBounds, monthSequence,
    // uuid
    uuid,
    // texto
    normalizeText,
    // download
    download, downloadJSON, downloadCSV,
  });

  // -----------------------------
  // Integrações leves (não críticas)
  // -----------------------------
  if (window.eventBus && typeof showToast === 'function') {
    // Feedback quando o IndexedDB estiver pronto
    window.eventBus.on('db:ready', () => showToast('Banco pronto! ✔️'));
  }
})();
