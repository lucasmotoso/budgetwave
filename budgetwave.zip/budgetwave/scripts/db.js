// path: budgetwave/scripts/db.js
/* IndexedDB do BudgetWave — v1 (refatorado)
   Stores:
     - transactions {id, date, description, categoryId, type, amount}; idx: date, categoryId, type
     - categories   {id, name, color, icon, monthlyGoal}; idx: name (unique)
     - settings     {key, value}
   Eventos (eventBus): 'db:ready', 'tx:changed', 'cat:changed', 'settings:changed'
   Observação: mantém compatibilidade com as funções globais já usadas no app.
*/

(() => {
  const BUS = window.eventBus || { on(){}, emit(){}, dispatch(){} };
  const { showToast: toast } = window.Utils || {};
  const DB_NAME = 'budgetwave_db';
  const DB_VERSION = 1;

  let dbRef = null;

  /* ---------- Abertura/Upgrade ---------- */
  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = (e) => {
        const db = e.target.result;

        // transactions
        if (!db.objectStoreNames.contains('transactions')) {
          const s = db.createObjectStore('transactions', { keyPath: 'id' });
          s.createIndex('date', 'date');
          s.createIndex('categoryId', 'categoryId');
          s.createIndex('type', 'type');
        }

        // categories
        if (!db.objectStoreNames.contains('categories')) {
          const s = db.createObjectStore('categories', { keyPath: 'id' });
          s.createIndex('name', 'name', { unique: true });
        }

        // settings
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };

      req.onsuccess = async (e) => {
        dbRef = e.target.result;

        // fecha/reabre automaticamente em caso de versionchange noutra aba
        dbRef.onversionchange = () => {
          try { dbRef.close(); } catch {}
          location.reload();
        };

        try {
          await seedIfEmpty(); // insere dados iniciais se vazio
        } catch (err) {
          console.warn('[DB] seedIfEmpty falhou:', err);
        }

        // Compat: alguns módulos chamam BUS.dispatch
        BUS.emit?.('db:ready');
        BUS.dispatch?.('db:ready');

        if (toast) toast('Banco pronto! ✔️');
        resolve(dbRef);
      };

      req.onerror = () => reject(req.error);
    });
  }

  /* ---------- Helpers ---------- */
  function store(name, mode = 'readonly') {
    if (!dbRef) throw new Error('DB não inicializado ainda');
    return dbRef.transaction(name, mode).objectStore(name);
  }

  function txWrap(name, mode, fn) {
    return new Promise((resolve, reject) => {
      try {
        const s = store(name, mode);
        const res = fn(s);
        // Se a função retornar diretamente algo, resolve; caso contrário escutamos onsuccess
        if (res?.onsuccess !== undefined) {
          res.onsuccess = () => resolve(res.result);
          res.onerror = () => reject(res.error);
        } else {
          resolve(res);
        }
      } catch (e) {
        reject(e);
      }
    });
  }

  /* ---------- SETTINGS ---------- */
  function getSetting(key) {
    return txWrap('settings', 'readonly', (s) => s.get(key))
      .then((row) => row?.value);
  }

  function setSetting(key, value) {
    return txWrap('settings', 'readwrite', (s) => s.put({ key, value }))
      .then(() => {
        BUS.emit?.('settings:changed', { key, value });
        BUS.dispatch?.('settings:changed', { key, value });
      });
  }

  /* ---------- CATEGORIES ---------- */
  function addCategory(cat) {
    cat.id ||= (window.Utils?.uuid?.() || Math.random().toString(36).slice(2));
    return txWrap('categories', 'readwrite', (s) => s.put(cat))
      .then(() => {
        BUS.emit?.('cat:changed');
        BUS.dispatch?.('cat:changed');
        return cat;
      });
  }
  const updateCategory = addCategory;

  function deleteCategory(id) {
    return txWrap('categories', 'readwrite', (s) => s.delete(id))
      .then(() => {
        BUS.emit?.('cat:changed');
        BUS.dispatch?.('cat:changed');
      });
  }

  function listCategories() {
    return txWrap('categories', 'readonly', (s) => s.getAll())
      .then((rows) => rows || []);
  }

  /* ---------- TRANSACTIONS ---------- */
  function addTx(t) {
    t.id ||= (window.Utils?.uuid?.() || Math.random().toString(36).slice(2));
    return txWrap('transactions', 'readwrite', (s) => s.put(t))
      .then(() => {
        BUS.emit?.('tx:changed');
        BUS.dispatch?.('tx:changed');
        return t;
      });
  }
  const updateTx = addTx;

  function deleteTx(id) {
    return txWrap('transactions', 'readwrite', (s) => s.delete(id))
      .then(() => {
        BUS.emit?.('tx:changed');
        BUS.dispatch?.('tx:changed');
      });
  }

  // Buscar todas as transações de um mês (YYYY, M[1-12])
  function getTxByMonth(year, month) {
    const lower = `${year}-${String(month).padStart(2, '0')}-01`;
    const upper = `${year}-${String(month).padStart(2, '0')}-31`;
    const range = IDBKeyRange.bound(lower, upper);

    return new Promise((resolve, reject) => {
      try {
        const idx = store('transactions').index('date');
        const out = [];
        const req = idx.openCursor(range);
        req.onsuccess = (e) => {
          const cur = e.target.result;
          if (cur) { out.push(cur.value); cur.continue(); }
          else resolve(out);
        };
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  /* ---------- API Genérica (útil p/ relatórios e debug) ---------- */
  function getAll(storeName) {
    return txWrap(storeName, 'readonly', (s) => s.getAll()).then((rows) => rows || []);
  }
  function put(storeName, value) {
    return txWrap(storeName, 'readwrite', (s) => s.put(value));
  }
  function remove(storeName, key) {
    return txWrap(storeName, 'readwrite', (s) => s.delete(key));
  }
  function count(storeName) {
    return txWrap(storeName, 'readonly', (s) => s.count()).then((n) => n || 0);
  }

  /* ---------- Seeds ---------- */
  async function seedIfEmpty() {
    // categorias
    const existingCats = await listCategories().catch(() => []);
    if ((existingCats || []).length === 0) {
      const defaults = [
        { name: 'Alimentação', color: '#ef4444', icon: 'fa-burger' },
        { name: 'Transporte',  color: '#3b82f6', icon: 'fa-car' },
        { name: 'Moradia',     color: '#10b981', icon: 'fa-house' },
        { name: 'Lazer',       color: '#f59e0b', icon: 'fa-gamepad' },
        { name: 'Saúde',       color: '#22c55e', icon: 'fa-heart-pulse' },
        { name: 'Educação',    color: '#8b5cf6', icon: 'fa-graduation-cap' },
        { name: 'Mercado',     color: '#14b8a6', icon: 'fa-cart-shopping' },
        { name: 'Renda',       color: '#eab308', icon: 'fa-coins' },
      ];
      // insere sem spammar eventos; dispara um único ao fim
      for (const d of defaults) {
        await txWrap('categories', 'readwrite', (s) => s.put({
          id: window.Utils?.uuid?.() || Math.random().toString(36).slice(2),
          ...d,
          monthlyGoal: null,
        }));
      }
      BUS.emit?.('cat:changed');
      BUS.dispatch?.('cat:changed');
    }

    // tema default (sincroniza com localStorage atual)
    const theme = await getSetting('theme').catch(() => null);
    if (!theme) {
      const initial = localStorage.getItem('bw_theme') || 'dark';
      await setSetting('theme', initial);
    }

    // se não houver transações, insere algumas no mês corrente
    const txCount = await count('transactions');
    if (txCount === 0) {
      const today = new Date();
      const y = today.getFullYear();
      const m = String(today.getMonth() + 1).padStart(2, '0');

      const cats = await listCategories();
      const cid = (name) => cats.find(c => c.name === name)?.id || '';

      const sample = [
        // Receitas
        { date: `${y}-${m}-01`, description: 'Salário',    categoryId: cid('Renda'),        type: 'income',  amount: 4200 },
        { date: `${y}-${m}-10`, description: 'Freelance',  categoryId: cid('Renda'),        type: 'income',  amount: 800 },
        { date: `${y}-${m}-20`, description: 'Cashback',   categoryId: cid('Renda'),        type: 'income',  amount: 60 },
        // Despesas
        { date: `${y}-${m}-03`, description: 'Supermercado',   categoryId: cid('Mercado'),     type: 'expense', amount: 320.55 },
        { date: `${y}-${m}-05`, description: 'Almoço',         categoryId: cid('Alimentação'), type: 'expense', amount: 48.90 },
        { date: `${y}-${m}-07`, description: 'Uber Aeroporto', categoryId: cid('Transporte'),  type: 'expense', amount: 65.00 },
        { date: `${y}-${m}-10`, description: 'Internet',       categoryId: cid('Moradia'),     type: 'expense', amount: 120.00 },
        { date: `${y}-${m}-12`, description: 'Cinema',         categoryId: cid('Lazer'),       type: 'expense', amount: 42.00 },
        { date: `${y}-${m}-15`, description: 'Farmácia',       categoryId: cid('Saúde'),       type: 'expense', amount: 35.90 },
      ];
      // idem: insere sem spammar; dispara um único evento após o lote
      for (const t of sample) {
        await txWrap('transactions', 'readwrite', (s) => s.put({
          id: window.Utils?.uuid?.() || Math.random().toString(36).slice(2),
          ...t,
        }));
      }
      BUS.emit?.('tx:changed');
      BUS.dispatch?.('tx:changed');
    }
  }

  /* ---------- Inicializa assim que o arquivo carregar ---------- */
  openDB();

  // Feedback opcional (somente se Utils.showToast existir)
  BUS.on?.('db:ready', () => { if (toast) toast('Banco pronto! ✔️'); });

  /* ---------- Exposição global (compat + API genérica) ---------- */
  // Compat: funções já usadas por outros módulos
  window.openDB = openDB;
  window.getSetting = getSetting;
  window.setSetting = setSetting;
  window.addCategory = addCategory;
  window.updateCategory = updateCategory;
  window.deleteCategory = deleteCategory;
  window.listCategories = listCategories;
  window.addTx = addTx;
  window.updateTx = updateTx;
  window.deleteTx = deleteTx;
  window.getTxByMonth = getTxByMonth;

  // API genérica
  window.DB = {
    open: openDB,
    getAll,
    put,
    remove,
    count,
    // acesso direto aos stores via helpers específicos
    getAllTransactions: () => getAll('transactions'),
    getAllCategories: () => getAll('categories'),
    getAllSettings: () => getAll('settings'),
  };
})();
