// path: budgetwave/scripts/dashboard.js
/* KPIs e Top5 do Dashboard (reativo)
   - KPIs: receitas, despesas e saldo (mês corrente)
   - Top 5 despesas do mês
   - Atualiza quando transações/categorias mudam
*/
(function(){
  function getYM(){ const d=new Date(); return { y:d.getFullYear(), m:d.getMonth()+1 } }
  function monthLabel(y,m){
    return new Date(y, m-1, 1).toLocaleDateString('pt-BR', { month:'long', year:'numeric' });
  }
  function el(id){ return document.getElementById(id); }

  async function renderKPIs(){
    const incEl = el('kpi-income'), expEl = el('kpi-expense'), balEl = el('kpi-balance');
    if(!incEl || !expEl || !balEl) return;

    const {y,m} = getYM();
    const txs = await getTxByMonth(y,m);

    let income = 0, expense = 0;
    for(const t of txs){
      const v = Number(t.amount)||0;
      if(t.type==='income') income += v;
      else if(t.type==='expense') expense += v;
    }
    const balance = income - expense;

    incEl.textContent = toBRL(income);
    expEl.textContent = toBRL(expense);
    balEl.textContent = toBRL(balance);
  }

  async function renderTop5(){
    const ul = el('top5-list'); if(!ul) return;
    const period = el('top5-period');

    const {y,m} = getYM();
    const [txs, cats] = await Promise.all([getTxByMonth(y,m), listCategories()]);
    const byId = new Map(cats.map(c=>[c.id,c]));

    // despesas do mês, maiores primeiro
    const expenses = txs.filter(t=>t.type==='expense');
    expenses.sort((a,b)=> (b.amount||0) - (a.amount||0));
    const top = expenses.slice(0,5);

    ul.innerHTML = '';
    for(const t of top){
      const c = byId.get(t.categoryId);
      const color = c?.color || 'var(--muted)';
      const cname = c?.name || '—';
      const li = document.createElement('li');
      li.className = 'top5__item';
      li.innerHTML = `
        <span class="badge" style="--_badge:${color}">
          <i class="fa-solid ${c?.icon||'fa-tag'}" style="color:${color}"></i>
          ${cname}
        </span>
        <span class="top5__desc">${escapeHtml(t.description||'—')}</span>
        <strong class="top5__val">${toBRL(Number(t.amount)||0)}</strong>
      `;
      ul.appendChild(li);
    }

    if(period) period.textContent = monthLabel(y,m);
    // mensagem vazia
    if(top.length===0){
      const li = document.createElement('li');
      li.className = 'top5__empty';
      li.textContent = 'Nenhuma despesa registrada neste mês.';
      ul.appendChild(li);
    }
  }

  async function renderAll(){
    await renderKPIs();
    await renderTop5();
  }

  // Eventos de ciclo de vida
  eventBus.on('db:ready', renderAll);
  eventBus.on('tx:changed', renderAll);
  eventBus.on('cat:changed', renderTop5);

  // fallback
  if (window.dbRef){ renderAll(); }
})();
